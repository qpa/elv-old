Unzip these "jar" files under $JRE_HOME/lib/ext.
