The src directory contains the source code for all the org.jpedal classes for JPedal and the build.xml to recreate under Ant.

Additional embedded font support can be added by putting pjes.jar on the classpath, where it will be auto-detected. This file
is NOT GPL and you may not distibute it without permission. This is given for genuine GPL projects, but you must contact us first.

Please note that JPedal uses some classes in com.idrsolutions and the source code for these is not included. The class files 
are in jpedal.jar and will be copied across by build.xml
