/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * Project Lead:  Mark Stephens (mark@idrsolutions.com)
 *
 * (C) Copyright 2006, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 *
 * ---------------
 * Commands.java
 * ---------------
 *
 * Original Author:  Mark Stephens (mark@idrsolutions.com)
 * Contributor(s):
 *
 */
package org.jpedal.examples.simpleviewer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

//<start-13>
import javax.imageio.ImageIO;
//<end-13>
import javax.media.jai.JAI;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;

import org.jpedal.PdfDecoder;
import org.jpedal.examples.simpleviewer.gui.SwingGUI;
import org.jpedal.examples.simpleviewer.gui.generic.GUISearchWindow;
import org.jpedal.examples.simpleviewer.gui.generic.GUIThumbnailPanel;
//<start-13>
import org.jpedal.examples.simpleviewer.gui.popups.AddHeaderFooterToPDFPages;
import org.jpedal.examples.simpleviewer.gui.popups.CropPDFPages;
import org.jpedal.examples.simpleviewer.gui.popups.DeletePDFPages;
import org.jpedal.examples.simpleviewer.gui.popups.EncryptPDFDocument;
import org.jpedal.examples.simpleviewer.gui.popups.InsertBlankPDFPage;
import org.jpedal.examples.simpleviewer.gui.popups.RotatePDFPages;
import org.jpedal.examples.simpleviewer.gui.popups.StampImageToPDFPages;
import org.jpedal.examples.simpleviewer.gui.popups.StampTextToPDFPages;
//<end-13>
import org.jpedal.examples.simpleviewer.gui.popups.SaveBitmap;
import org.jpedal.examples.simpleviewer.gui.popups.SaveImage;
import org.jpedal.examples.simpleviewer.gui.popups.SavePDF;
import org.jpedal.examples.simpleviewer.gui.popups.ErrorDialog;
import org.jpedal.examples.simpleviewer.gui.popups.SaveText;
import org.jpedal.examples.simpleviewer.utils.BrowserLauncher;
import org.jpedal.examples.simpleviewer.utils.Exporter;
import org.jpedal.examples.simpleviewer.utils.FileFilterer;
import org.jpedal.examples.simpleviewer.utils.IconiseImage;
import org.jpedal.examples.simpleviewer.utils.ItextFunctions;
import org.jpedal.examples.simpleviewer.utils.Messages;
import org.jpedal.examples.simpleviewer.utils.Printer;
import org.jpedal.examples.simpleviewer.utils.PropertiesFile;
import org.jpedal.examples.simpleviewer.utils.SwingWorker;
import org.jpedal.exception.PdfException;
import org.jpedal.objects.PdfFileInformation;
import org.jpedal.objects.PdfPageData;
import org.jpedal.utils.LogWriter;
import org.jpedal.utils.Strip;

/**code to execute the actual commands*/
public class Commands {
	
	public static final int INFO = 1;
	public static final int BITMAP = 2;
	public static final int IMAGES = 3;
	public static final int TEXT = 4;
	public static final int SAVE = 5;
	public static final int PRINT = 6;
	public static final int EXIT = 7;
	public static final int AUTOSCROLL = 8;
	public static final int DOCINFO = 9;
	public static final int OPENFILE = 10;
	public static final int BOOKMARK = 11;
	public static final int FIND = 12;
	public static final int SNAPSHOT = 13;
	public static final int OPENURL = 14;
	public static final int VISITWEBSITE = 15;
	public static final int PREVIOUSDOCUMENT = 16;
	public static final int NEXTDOCUMENT = 17;
	
	public static final int FIRSTPAGE = 50;
	public static final int FBACKPAGE = 51;
	public static final int BACKPAGE = 52;
	public static final int FORWARDPAGE = 53;
	public static final int FFORWARDPAGE = 54;
	public static final int LASTPAGE = 55;
	public static final int GOTO = 56;
	
	/**combo boxes start at 250*/
	public static final int QUALITY = 250;
	public static final int ROTATION = 251;
	public static final int SCALING = 252;
	
	/**
	 * external/itext menu options start at 500 - add your own CONSTANT here
	 * and refer to action using name at ALL times
	 */
	public static final int SAVEFORM = 500;
	public static final int PDF = 501;
	public static final int ROTATE=502;
	public static final int DELETE=503;
	public static final int ADD=504;
	public static final int SECURITY=505;
	public static final int ADDHEADERFOOTER=506;
	public static final int STAMPTEXT=507;
	public static final int STAMPIMAGE=508;
	public static final int SETCROP=509;
	public static final int NUP = 510;
	public static final int HANDOUTS = 511;
	//public static final int NEWFUNCTION = 512;
	
	
	private Values commonValues;
	private SwingGUI currentGUI;
	private PdfDecoder decode_pdf;
	
	private GUIThumbnailPanel thumbnails;
	
	/**image if file tiff or png or jpg*/
	private BufferedImage img=null;
	
	private int noOfRecentDocs;
	private RecentDocuments recent;
	
	private JMenuItem[] recentDocuments;
	
	private final Font headFont=new Font("SansSerif",Font.BOLD,14);
	
	/**flag used for text popup display to show if menu disappears*/
	private boolean display=true;
	
	private PropertiesFile properties; 
	final private GUISearchWindow searchFrame;
	
	private Printer currentPrinter;
	
	/**atomic lock for open thread*/
	private boolean isOpening;
	
	public Commands(Values commonValues,SwingGUI currentGUI,PdfDecoder decode_pdf,GUIThumbnailPanel thumbnails, 
			PropertiesFile properties , GUISearchWindow searchFrame,Printer currentPrinter) {
		this.commonValues=commonValues;
		this.currentGUI=currentGUI;
		this.decode_pdf=decode_pdf;
		this.thumbnails=thumbnails;
		this.properties=properties;
		this.currentPrinter=currentPrinter;
		
		this.noOfRecentDocs=properties.getNoRecentDocumentsToDisplay();
		recentDocuments = new JMenuItem[noOfRecentDocs];
		this.recent=new RecentDocuments(noOfRecentDocs,properties);
		
		this.searchFrame=searchFrame;
	}
	
	/**
	 * main routine which executes code for current command
	 */
	public void executeCommand(int ID) {
		
		String fileToOpen;
		switch(ID){
		
		case INFO:
			currentGUI.getInfoBox();
			break;
			
		case BITMAP:
			if(commonValues.getSelectedFile()==null){
				JOptionPane.showMessageDialog(currentGUI.getFrame(),"No file open");
			}else{
				//get values from user
				SaveBitmap current_selection = new SaveBitmap(commonValues.getInputDir(), commonValues.getPageCount(),commonValues.getCurrentPage());
				int userChoice=current_selection.display(currentGUI.getFrame(),"Save pages as Bitmap images");
				
				//get parameters and call if YES
				if (userChoice == JOptionPane.OK_OPTION){
					Exporter exporter=new Exporter(currentGUI,commonValues.getSelectedFile(),decode_pdf);	        		
					exporter.extractPagesAsImages(current_selection);               
				}
			}
			break;
			
		case SAVE:
			saveFile();
			break;
			
		case PRINT:
			if(commonValues.getSelectedFile()!=null){
				if(!currentPrinter.isPrinting()){
					if(!commonValues.isPDF()){
						currentGUI.showMessageDialog("Printing is not available on images at this time");
					}else{
						currentPrinter.printPDF(decode_pdf,currentGUI);
					}
				}else
					currentGUI.showMessageDialog(Messages.getMessage("PdfViewerPrintFinish.message"));
			}else
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerNoFile.message")); 
			break;
			
		case EXIT:
			if(currentPrinter.isPrinting())
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerStillPrinting.text"));
			else
				exit();
			break;
			
		case AUTOSCROLL:
			currentGUI.toogleAutoScrolling();
			break;
			
		case DOCINFO:
			if(!commonValues.isPDF())
				currentGUI.showMessageDialog("This feature can only be used on pdf files");
			else
				currentGUI.showDocumentProperties(commonValues.getSelectedFile(), commonValues.getInputDir(), commonValues.getFileSize(), commonValues.getPageCount(), commonValues.getCurrentPage());
			break;
			
		case OPENFILE:
			
			//<start-forms>
			/**
			 * warn user on forms
			 */
			handleUnsaveForms();
			//<end-forms>
			
			if(currentPrinter.isPrinting())
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerPrintWait.message"));
			else if(commonValues.isProcessing() || isOpening)
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerDecodeWait.message"));
			else{
				selectFile();
			}
			break;
			
		case BOOKMARK:
			currentGUI.togglePDFOutline();
			break;
			
			
		case OPENURL:
			
			//<start-forms>
			/**
			 * warn user on forms
			 */
			handleUnsaveForms();
			//<end-forms>
			
			if(currentPrinter.isPrinting())
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerPrintWait.message"));
			else if(commonValues.isProcessing() || isOpening)
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerDecodeWait.message"));
			else{
				String newFile=selectURL();
					if(newFile!=null)
						commonValues.setSelectedFile(newFile);
				}
			
			break;
			
		case VISITWEBSITE:
			try {
				BrowserLauncher.openURL("http://www.jpedal.org");
			} catch (IOException e1) {
				currentGUI.showMessageDialog("Unable to launch browser");
			}
			break;
			
		case PREVIOUSDOCUMENT:
			if(currentPrinter.isPrinting())
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerPrintWait.message"));
			else if(commonValues.isProcessing() || isOpening)
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerDecodeWait.message"));
			else{
				fileToOpen=recent.getPreviousDocument();
				if(fileToOpen!=null)
					open(fileToOpen);
			}
			break;
			
		case NEXTDOCUMENT:
			if(currentPrinter.isPrinting())
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerPrintWait.message"));
			else if(commonValues.isProcessing() || isOpening)
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerDecodeWait.message"));
			else{
				fileToOpen=recent.getNextDocument();
				if(fileToOpen!=null)
					open(fileToOpen);
			}
			break;			
			
		case FIRSTPAGE:
			if((commonValues.getSelectedFile()!=null)&&(commonValues.getPageCount()>1)&&(commonValues.getCurrentPage()!=1))
				back(commonValues.getCurrentPage()-1);
			break;
			
		case FBACKPAGE:
			if(commonValues.getSelectedFile()!=null)
				back(10);
			break;
			
		case BACKPAGE:
			if(commonValues.getSelectedFile()!=null)
				back(1);
			break;
			
		case FORWARDPAGE:
			if(commonValues.getSelectedFile()!=null)
				forward(1);
			break;
			
		case FFORWARDPAGE:
			if(commonValues.getSelectedFile()!=null)
				forward(10);
			break;
			
		case LASTPAGE:
			if((commonValues.getSelectedFile()!=null)&&(commonValues.getPageCount()>1)&&(commonValues.getPageCount()-commonValues.getCurrentPage()>0))
				forward(commonValues.getPageCount()-commonValues.getCurrentPage());
			break;
			
		case GOTO:
			String page = currentGUI.showInputDialog("Enter page number", "Goto Page", JOptionPane.QUESTION_MESSAGE);
			if(page != null)
				gotoPage(page);
			break;
			
		case QUALITY:
			if(!commonValues.isProcessing()){
				boolean useHiresImage=true;
				if(currentGUI.getSelectedComboIndex(Commands.QUALITY)==0)
					useHiresImage = false;
				
				//tell user page will be redrawn
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerReparseWait.message"));
				
				//reset flag and re-decode page
				decode_pdf.useHiResScreenDisplay(useHiresImage);
				commonValues.setUseHiresImage(useHiresImage);
				
				try {
					currentGUI.decodePage(false);
				} catch (Exception e1) {
					System.err.println("Exception " + e1 + " decoding page after image quality changes");
					e1.printStackTrace();
				}
				decode_pdf.updateUI();
			}
			break;
			
		case SCALING:
			if(!commonValues.isProcessing()){
				if(commonValues.getSelectedFile()!=null)
					currentGUI.zoom();
			}
			break;
			
		case ROTATION:
			if(commonValues.getSelectedFile()!=null)
				currentGUI.rotate(); 
			break;
		
		//<start-forms>
		/**
		 * external/itext menu options start at 500 - add your own code here
		 */
		case SAVEFORM:
			saveChangedForm();
			break;
		//<end-forms>
		
		case PDF:
			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				//get values from user
				SavePDF current_selection = new SavePDF(commonValues.getInputDir(), commonValues.getPageCount(), commonValues.getCurrentPage());
				int userChoice=current_selection.display(currentGUI.getFrame(),"Save pages as PDF files");
				
				//get parameters and call if YES
				if (userChoice == JOptionPane.OK_OPTION){
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
					itextFunctions.extractPagesToNewPDF(current_selection);
				}
			}
			break;
			
		//<start-13>
		case ROTATE:
			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				//get values from user
				RotatePDFPages current_selection = new RotatePDFPages(commonValues.getInputDir(), commonValues.getPageCount(), commonValues.getCurrentPage());
				int userChoice=current_selection.display(currentGUI.getFrame(),"Rotate Pages");
				
				//get parameters and call if YES
				if (userChoice == JOptionPane.OK_OPTION){
					
					PdfPageData currentPageData=decode_pdf.getPdfPageData();
					
					decode_pdf.closePdfFile();
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
					itextFunctions.rotate(commonValues.getPageCount(),currentPageData,current_selection);
					open(commonValues.getSelectedFile());
				}
			}
            
			break;

		case SETCROP:
			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				//get values from user
				CropPDFPages cropPage = new CropPDFPages(commonValues.getInputDir(), commonValues.getPageCount(), commonValues.getCurrentPage());
				int cropPageChoice=cropPage.display(currentGUI.getFrame(),"Crop Pages");
				
				//get parameters and call if YES
				if (cropPageChoice == JOptionPane.OK_OPTION){
					
					PdfPageData currentPageData=decode_pdf.getPdfPageData();
					
					decode_pdf.closePdfFile();
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
					itextFunctions.setCrop(commonValues.getPageCount(),currentPageData,cropPage);
					open(commonValues.getSelectedFile());
				}
			}
            
			break;

		case NUP:
			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				JFileChooser chooser = new JFileChooser();
				chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
				
				int approved=chooser.showSaveDialog(null);
				if(approved==JFileChooser.APPROVE_OPTION){
					
					File file = chooser.getSelectedFile();
					
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
		            itextFunctions.nup(file.getAbsolutePath());
				}
			}
			
			break;
			
		case HANDOUTS:
			
			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				JFileChooser chooser1 = new JFileChooser();
				chooser1.setFileSelectionMode(JFileChooser.FILES_ONLY);
				
				int approved1=chooser1.showSaveDialog(null);
				if(approved1==JFileChooser.APPROVE_OPTION){
					
					File file = chooser1.getSelectedFile();
					
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
					itextFunctions.handouts(file.getAbsolutePath());
				}
			}
			break;
			
		case DELETE:

			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				//get values from user
				DeletePDFPages deletedPages = new DeletePDFPages(commonValues.getInputDir(), commonValues.getPageCount(), commonValues.getCurrentPage());
				int deletedPagesChoice=deletedPages.display(currentGUI.getFrame(),"Delete Pages");
				
				//get parameters and call if YES
				if (deletedPagesChoice == JOptionPane.OK_OPTION){
					
					PdfPageData currentPageData=decode_pdf.getPdfPageData();
					
					decode_pdf.closePdfFile();
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
					itextFunctions.delete(commonValues.getPageCount(),currentPageData,deletedPages);
					open(commonValues.getSelectedFile());
				}
			}
			
			break;
			
		case ADDHEADERFOOTER:
			
			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				
				//get values from user
				AddHeaderFooterToPDFPages addHeaderFooter = new AddHeaderFooterToPDFPages(commonValues.getInputDir(), commonValues.getPageCount(), commonValues.getCurrentPage());
				int headerFooterPagesChoice=addHeaderFooter.display(currentGUI.getFrame(),"Add Headers and Footers");
				
				//get parameters and call if YES
				if (headerFooterPagesChoice == JOptionPane.OK_OPTION){
					
					PdfPageData currentPageData=decode_pdf.getPdfPageData();
					
					decode_pdf.closePdfFile();
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
					itextFunctions.addHeaderFooter(commonValues.getPageCount(),currentPageData,addHeaderFooter);
					open(commonValues.getSelectedFile());
				}
			}
			
			break;
			
		case STAMPTEXT:
			
			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				//get values from user
				StampTextToPDFPages stampText = new StampTextToPDFPages(commonValues.getInputDir(), commonValues.getPageCount(), commonValues.getCurrentPage());
				int stampTextChoice=stampText.display(currentGUI.getFrame(),"Text Stamp");
				
				//get parameters and call if YES
				if (stampTextChoice == JOptionPane.OK_OPTION){
					
					PdfPageData currentPageData=decode_pdf.getPdfPageData();
					
					decode_pdf.closePdfFile();
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
					itextFunctions.stampText(commonValues.getPageCount(),currentPageData,stampText);
					open(commonValues.getSelectedFile());
				}
			}
			
			break;
			
		case STAMPIMAGE:
			
			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				
				//get values from user
				StampImageToPDFPages stampImage = new StampImageToPDFPages(commonValues.getInputDir(), commonValues.getPageCount(), commonValues.getCurrentPage());
				int stampImageChoice=stampImage.display(currentGUI.getFrame(),"Image Stamp");
				
				//get parameters and call if YES
				if (stampImageChoice == JOptionPane.OK_OPTION){
					
					PdfPageData currentPageData=decode_pdf.getPdfPageData();
					
					decode_pdf.closePdfFile();
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
					itextFunctions.stampImage(commonValues.getPageCount(),currentPageData,stampImage);
					open(commonValues.getSelectedFile());
				}
			}
			
			break;
			
		case ADD:
			
			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				//get values from user
				InsertBlankPDFPage addPage = new InsertBlankPDFPage(commonValues.getInputDir(), commonValues.getPageCount(), commonValues.getCurrentPage());
				int positionToAdd=addPage.display(currentGUI.getFrame(),"Insert Blank Page");
				
				//get parameters and call if YES
				if (positionToAdd == JOptionPane.OK_OPTION){
					
					PdfPageData currentPageData=decode_pdf.getPdfPageData();
					
					decode_pdf.closePdfFile();
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
					itextFunctions.add(commonValues.getPageCount(),currentPageData,addPage);
					open(commonValues.getSelectedFile());
				}
			}
			
			break;
			
		case SECURITY:
			
			if(commonValues.getSelectedFile()==null){
				currentGUI.showMessageDialog("No file open");
			}else{
				//get values from user
				EncryptPDFDocument encryptPage = new EncryptPDFDocument(commonValues.getInputDir(), commonValues.getPageCount(), commonValues.getCurrentPage());
				int encrypt=encryptPage.display(currentGUI.getFrame(),"Standard Security");
				
				//get parameters and call if YES
				if (encrypt == JOptionPane.OK_OPTION){
					
					PdfPageData currentPageData=decode_pdf.getPdfPageData();
					
					decode_pdf.closePdfFile();
					ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
					itextFunctions.encrypt(commonValues.getPageCount(),currentPageData,encryptPage);
					open(commonValues.getSelectedFile());
				}
			}
			
			break;
		//<end-13>
			
		//case MYFUNCTION:
			/**add your code here. We recommend you put it in an external class such as 
			 * 
			 * MyFactory.newFunction(parameters);
			 *
			 * or
			 * 
			 * ItextFunctions itextFunctions=new ItextFunctions(currentGUI.getFrame(),commonValues.getSelectedFile(),decode_pdf);
			 * itextFunctions.newFeature(parameters);
			 */
			//break;
			
		default:
			System.out.println("No menu item set");
		}
	}
	
	//<start-forms>
	 /**add listeners to forms to track changes - could also do other tasks like send data to
	  * database server
	  */
	private void saveChangedForm() {
		org.jpedal.objects.acroforms.AcroRenderer formRenderer=decode_pdf.getCurrentFormRenderer();
		
		if(formRenderer==null)
			return;
		
		List names=null;
		
		try {
			names = formRenderer.getComponentNameList();
		} catch (PdfException e1) {
			e1.printStackTrace();
		}
		
		if(names==null){
			currentGUI.showMessageDialog("No fields on this page");
		}else{
			/**
			 * create the file chooser to select the file
			 */
			File file=null;
			String fileToSave="";
			boolean finished=false;
			while(!finished){
				JFileChooser chooser = new JFileChooser(commonValues.getInputDir());
				chooser.setSelectedFile(new File(commonValues.getInputDir()+"/"+commonValues.getSelectedFile()));
				chooser.addChoosableFileFilter(new FileFilterer(new String[]{"pdf"}, "Pdf (*.pdf)")); 
				chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
				//set default name to current file name 
				int approved=chooser.showSaveDialog(null);
				if(approved==JFileChooser.APPROVE_OPTION){
					file = chooser.getSelectedFile();
					fileToSave=file.getAbsolutePath();
					
					if(!fileToSave.endsWith(".pdf")){
						fileToSave += ".pdf";
						file=new File(fileToSave);
					}
					
					if(fileToSave.equals(commonValues.getSelectedFile())){
						currentGUI.showMessageDialog("You cannot save the forms data to the file currently open.  You must save to a different file"); 
						continue;
					}
					
					if(file.exists()){
						int n=currentGUI.showConfirmDialog(fileToSave+"\n" +
								"The file already exists.\n" +
								"Replace the existing file?","Resave Forms Data",JOptionPane.YES_NO_OPTION);
						if(n==1)
							continue;
					}
					finished=true;
				}else{
					return;
				}
			}
			
			ItextFunctions itextFunctions=new ItextFunctions(currentGUI,commonValues.getSelectedFile(),decode_pdf);
			itextFunctions.saveFormsData(fileToSave);		
			
			/**
			 * reset flag and graphical clue
			 */
			commonValues.setFormsChanged(false);
			currentGUI.setViewerTitle(null);
			
		}
	}
	
	/**
	 * warns user forms unsaved and offers save option
	  */
	public void handleUnsaveForms() {
		if((commonValues.isFormsChanged())&&(commonValues.isItextOnClasspath())){
			int n = currentGUI.showConfirmDialog(Messages.getMessage("PdfViewerFormsUnsavedOptions.message"),Messages.getMessage("PdfViewerFormsUnsavedWarning.message"), JOptionPane.YES_NO_OPTION);
			
			if(n==JOptionPane.YES_OPTION)
				saveChangedForm();
		}
		commonValues.setFormsChanged(false);
	}
	//<end-forms>
	
	
	
	/**
	 * called by nav functions to decode next page
	 */
	private void decodeImage(final boolean resizePanel) {
		
		//remove any search highlight
		decode_pdf.setFoundTextAreas(null);
		
		currentGUI.setRectangle(null);
		
		//stop user changing scaling while decode in progress
		currentGUI.resetComboBoxes(false);
		
		decode_pdf.clearScreen();
		
		/** if running terminate first */
		thumbnails.terminateDrawing();
		
		commonValues.setProcessing(true);
		
		SwingWorker worker = new SwingWorker() {
			public Object construct() {
				
				try {
					
					currentGUI.updateStatusMessage("Decoding Page");
					
					if(img!=null)
						decode_pdf.addImage(img);
					/**
					 * make sure screen fits display nicely
					 */
					if ((resizePanel) && (thumbnails.isShownOnscreen()))
						currentGUI.zoom();
					
					if (Thread.interrupted())
						throw new InterruptedException();
					currentGUI.setPageNumber();
					
					//<start-13>
					currentGUI.setViewerTitle(null); //restore title
					//<end-13>
					
				} catch (Exception e) {
					//<start-13>
					currentGUI.setViewerTitle(null); //restore title
					//<end-13>
				}
				
				currentGUI.setStatusProgress(100);
				
				//reanable user changing scaling 
				currentGUI.resetComboBoxes(true);
		
				//ensure drawn
				decode_pdf.repaint();
				
				return null;
			}
		};
		
		worker.start();
		
	}
	
	/**
	 *  initial method called to open a new PDF
	 */
	protected boolean openUpFile(String selectedFile) {
		
		commonValues.maxViewY=0;// rensure reset for any viewport
		
		boolean fileCanBeOpened = true;
		
		/** reset default values */
		currentGUI.setScalingToDefault(); 
		
		decode_pdf.closePdfFile();
		
		/** ensure all data flushed from PdfDecoder before we decode the file */
		//decode_pdf.flushObjectValues(true);
		
		try {
			
			/** opens the pdf and reads metadata */
			if(commonValues.isPDF()){
				if(selectedFile.startsWith("http:")){
					try{
						decode_pdf.openPdfFileFromURL(commonValues.getSelectedFile());
					}catch(Exception e){
						currentGUI.showMessageDialog("Unable to open URL");
						selectedFile=null;
						fileCanBeOpened=false;
					}
				}else
					decode_pdf.openPdfFile(commonValues.getSelectedFile());
			}else{
				
				boolean isTiff=selectedFile.toLowerCase().indexOf(".tif")!=-1;
				
				//<start-13>
				//decode image
				if(isTiff){
					try {
						// Load the source image from a file.
						img = JAI.create("fileload", commonValues.getSelectedFile()).getAsBufferedImage();
					} catch (Exception e) {
						LogWriter.writeLog("Exception " + e + " loading " + commonValues.getSelectedFile());
					}
				}else{
					try {
						// Load the source image from a file.
						img=ImageIO.read(new File(commonValues.getSelectedFile()));
					} catch (Exception e) {
						LogWriter.writeLog("Exception " + e + " loading " + commonValues.getSelectedFile());
					}
					
				}
				/**
				//<end-13>
				try {
					// Load the source image from a file.
					img = JAI.create("fileload", commonValues.getSelectedFile()).getAsBufferedImage();
				} catch (Exception e) {
					LogWriter.writeLog("Exception " + e + " loading " + commonValues.getSelectedFile());
				}
				/**/
				
				
				//set values for page display
				decode_pdf.resetForNonPDFPage();
				PdfPageData page_data = decode_pdf.getPdfPageData();
				if(img!=null)
					page_data.setMediaBox("0 0 "+img.getWidth()+" "+img.getHeight());
				page_data.checkSizeSet(1);
				currentGUI.resetRotationBox();
				
			}
			
			currentGUI.updateStatusMessage("opening file");
			
			/** flag up if encryption present */
			
			/** popup window if needed */
			if ((fileCanBeOpened)&&(decode_pdf.isEncrypted()) && (!decode_pdf.isFileViewable())) {
				fileCanBeOpened = false;
				
				//<start-13>
				/**
				 * //<end-13>JOptionPane.showMessageDialog(currentGUI.frame,"Please
				 * use Java 1.4 to display encrypted files"); //<start-13>
				 */
				
				String password = currentGUI.showInputDialog(Messages.getMessage("PdfViewerPassword.message")); //$NON-NLS-1$
				
				/** try and reopen with new password */
				if (password != null) {
					decode_pdf.setEncryptionPassword(password);
					//decode_pdf.verifyAccess();
					
					if (decode_pdf.isFileViewable())
						fileCanBeOpened = true;
					
				}

                if(!fileCanBeOpened)
                currentGUI.showMessageDialog(Messages.getMessage("PdfViewerPasswordRequired.message"));
				//<end-13>
			}
			
			currentGUI.removeOutlinePanels();
			
			
			if (fileCanBeOpened) {
				
				if(!commonValues.isContentExtractor()){
					properties.addRecentDocument(commonValues.getSelectedFile());
					updateRecentDocuments(properties.getRecentDocuments());
				}
				
				recent.addToFileList(commonValues.getSelectedFile());
				
				/** reset values */
				commonValues.setCurrentPage(1);
			}
			
		} catch (Exception e) {
			System.err.println("Exception " + e + " opening file");
			
			ErrorDialog.showError(e,Messages.getMessage("PdfViewerOpenerror"),currentGUI.getFrame());
			System.exit(1);
			
		}
		
		return fileCanBeOpened;
		
	}
	
	/**
	 *  checks file can be opened (permission) 
	 */
	protected void openFile(String selectedFile) {
		
		//get any user set dpi
		String hiresFlag=System.getProperty("hires");
		if(hiresFlag!=null)
			commonValues.setUseHiresImage(true);
		
		//get any user set dpi
		String memFlag=System.getProperty("memory");
		if(memFlag!=null){
			commonValues.setUseHiresImage(false);
		}
		
		//reset flag
		thumbnails.resetToDefault();
		
		//<start-forms>
		//flush forms list
		currentGUI.setNoPagesDecoded();
		//<end-forms>
		
		
		commonValues.maxViewY=0;// rensure reset for any viewport
		commonValues.setPDF(selectedFile.toLowerCase().trim().endsWith(".pdf"));
		
		currentGUI.setQualityBoxVisible(commonValues.isPDF());
				
		boolean fileCanBeOpened=openUpFile(commonValues.getSelectedFile());
		commonValues.setCurrentPage(1);
		
		try{
			if(fileCanBeOpened)
				processPage();	
			else{
				currentGUI.setViewerTitle("No file open");
				decode_pdf.clearScreen();
				this.currentGUI.zoom();
				commonValues.setPageCount(1);
				commonValues.setCurrentPage(1);
			}
		}catch(Exception e){
			System.err.println("Exception " + e + " decoding file");
			
		}
		
		commonValues.setProcessing(false);
	}
	
	
	/**
	 * decode and display selected page
	 */
	protected void processPage() {
		
		if(commonValues.isPDF()){
			/**
			 * get PRODUCER and if OCR disable text printing
			 */
			PdfFileInformation currentFileInformation=decode_pdf.getFileInformationData();
			
			/**switch all on by default*/
			decode_pdf.setRenderMode(PdfDecoder.RENDERIMAGES+PdfDecoder.RENDERTEXT);
			
			String[] values=currentFileInformation.getFieldValues();
			String[] fields=currentFileInformation.getFieldNames();
			
			/** holding all creators that produce OCR pdf's */
			String[] ocr = {"TeleForm","dgn2pdf"};
			
			for(int i=0;i<fields.length;i++){
				
				if((fields[i].equals("Creator"))|(fields[i].equals("Producer"))){
					
					for(int j=0;j<ocr.length;j++){
						
						if(values[i].equals(ocr[j])){
							
							decode_pdf.setRenderMode(PdfDecoder.RENDERIMAGES);
							
							/**
							 * if we want to use java 13 JPEG conversion
							 */
							decode_pdf.setEnableLegacyJPEGConversion(true);
							
						}
					}
				}
				
				boolean currentProcessingStatus=commonValues.isProcessing();
				commonValues.setProcessing(true);	//stops listeners processing spurious event			
				if(commonValues.isUseHiresImage()){
					decode_pdf.useHiResScreenDisplay(true);
					currentGUI.setSelectedComboIndex(Commands.QUALITY,1);
				}else{
					decode_pdf.useHiResScreenDisplay(false);
					currentGUI.setSelectedComboIndex(Commands.QUALITY,0);
				}
				commonValues.setProcessing(currentProcessingStatus);
				
			}
		}
		commonValues.setPageCount(decode_pdf.getPageCount());
		
		/**special customisations for images*/
		if(!commonValues.isPDF()){
			commonValues.setPageCount(1);
			decode_pdf.useHiResScreenDisplay(true);
			
		}
		
		
		if(commonValues.getPageCount()<commonValues.getCurrentPage()){
			commonValues.setCurrentPage(commonValues.getPageCount());
			System.err.println(commonValues.getCurrentPage()+ " out of range. Opening on last page");
			LogWriter.writeLog(commonValues.getCurrentPage()+ " out of range. Opening on last page");
		}
		
		
		//values extraction mode,dpi of images, dpi of page as a factor of 72

        decode_pdf.setExtractionMode(0, 72, currentGUI.getScaling());
        /***/

		//resize (ensure at least certain size)
		currentGUI.zoom();
		
		//add a border
		decode_pdf.setPDFBorder(BorderFactory.createLineBorder(Color.black, 1));
		
		/** turn off border in printing */
		decode_pdf.disableBorderForPrinting();
		
		
		/**
		 * update the display, including any rotation
		 */
		currentGUI.setPageNumber();
		
		currentGUI.resetRotationBox();
		
		if(commonValues.isPDF())
			currentGUI.decodePage(true);
		else
			decodeImage(true);
		
	}
	
	/** opens a pdf file and calls the display/decode routines */
	public void selectFile() {
		
		
		/**
		 * create the file chooser to select the file
		 */
		final JFileChooser chooser = new JFileChooser(commonValues.getInputDir());
		if(commonValues.getSelectedFile()!=null)
			chooser.setSelectedFile(new File(commonValues.getSelectedFile()));
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		
		String[] pdf = new String[] { "pdf" };
		String[] png = new String[] { "png","tif","tiff","jpg","jpeg" }; 
		chooser.addChoosableFileFilter(new FileFilterer(png, "Images (Tiff, Jpeg,Png)"));
		chooser.addChoosableFileFilter(new FileFilterer(pdf, "Pdf (*.pdf)")); 
		
		final int state = chooser.showOpenDialog(currentGUI.getFrame());
				
		//ensure immediate redraw of blank screen
		//decode_pdf.invalidate();
		//decode_pdf.repaint();
		
		final File file = chooser.getSelectedFile();
		
		/**
		 * decode
		 */
		if (file != null && state == JFileChooser.APPROVE_OPTION) {
			
			String ext=file.getName().toLowerCase();
			boolean isValid=((ext.endsWith(".pdf"))||
					(ext.endsWith(".tif"))||(ext.endsWith(".tiff"))||
					(ext.endsWith(".png"))||
					(ext.endsWith(".jpg"))||(ext.endsWith(".jpeg")));
			
			if(isValid){
				/** save path so we reopen her for later selections */
				try {
					commonValues.setInputDir(chooser.getCurrentDirectory().getCanonicalPath());
					open(file.getAbsolutePath());
					
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}else{
				decode_pdf.repaint();
				currentGUI.showMessageDialog( Messages.getMessage("PdfInvalidFile")); 			
			}
			
		} else { //no file selected so redisplay old
			decode_pdf.repaint();
			currentGUI.showMessageDialog( Messages.getMessage("PdfViewerNoSelection")); 
			
		}
	}
	
	private String selectURL() {
		
		String selectedFile = currentGUI.showInputDialog("Enter full URL of file");
		
		if((selectedFile!=null) &&(!selectedFile.trim().startsWith("http://"))){
			currentGUI.showMessageDialog("URL must start http://");
			selectedFile=null;
		}
		
		if(selectedFile!=null && !selectedFile.endsWith(".pdf")){
			currentGUI.showMessageDialog("You must enter a valid PDF file");
			selectedFile=null;
		}
		
		if((selectedFile!=null) ){
			
			commonValues.setSelectedFile(selectedFile);
			
			boolean failed=false;
			try {
				URL testExists=new URL(selectedFile);
				URLConnection conn=testExists.openConnection();
				
				if(conn.getContent()==null)
					failed=true;
			} catch (Exception e) {
				failed=true;
			}
			
			if(failed){
				selectedFile=null;
				currentGUI.showMessageDialog("URL "+selectedFile+" does not exist or cannot be opened");
			}
		}
		
		//ensure immediate redraw of blank screen
		//decode_pdf.invalidate();
		//decode_pdf.repaint();
		
		/**
		 * decode
		 */
		if (selectedFile != null ) {
			try {
				
				commonValues.setFileSize(0);
				
				/** save path so we reopen her for later selections */
				//commonValues.setInputDir(new URL(commonValues.getSelectedFile()).getPath());
				
				currentGUI.setViewerTitle(null);
				
			} catch (Exception e) {
				System.err.println("Exception " + e + " getting paths");
			}
			
			/**
			 * open the file
			 */
			if ((selectedFile != null) && (commonValues.isProcessing() == false)) {
				
				/**
				 * trash previous display now we are sure it is not needed
				 */
				//decode_pdf.repaint();
				
				/** if running terminate first */
				thumbnails.terminateDrawing();
				
				decode_pdf.flushObjectValues(true);
				
				//reset the viewableArea before opening a new file
				decode_pdf.resetViewableArea();
				
				//<start-13>
				thumbnails.removeComponentListener();
				//<end-13>
				
				openFile(commonValues.getSelectedFile());
				
			}
			
		} else { //no file selected so redisplay old
			decode_pdf.repaint();
			currentGUI.showMessageDialog(Messages.getMessage("PdfViewerNoSelection")); 
			
		}
		
		return selectedFile;
	}
	
	/**move forward one page*/
	private void forward(int count) {
		
		if (!commonValues.isProcessing()) { //lock to stop multiple accesses
			
			/**if in range update count and decode next page. Decoded pages are cached so will redisplay
			 * almost instantly*/
			int updatedTotal=commonValues.getCurrentPage()+count;
			
			int testValue=updatedTotal;
			//special case of facing view
			if(decode_pdf.getDisplayView()==PdfDecoder.FACING)
				testValue++;
			
			if (testValue <= commonValues.getPageCount()) {
				commonValues.setCurrentPage(updatedTotal);
				
				currentGUI.resetStatusMessage("Loading Page "+commonValues.getCurrentPage());
				/**reset as rotation may change!*/
				decode_pdf.setPageParameters(currentGUI.getScaling(), commonValues.getCurrentPage());
				
				//would reset scaling on page change to default
				//currentGUI.setScalingToDefault(); 
				
				//decode the page
				currentGUI.decodePage(false);
				
				//if scaling to window reset screen to fit rotated page
				if(currentGUI.getSelectedComboIndex(Commands.SCALING)<3)
					currentGUI.zoom();
				
			}
		}else
			currentGUI.showMessageDialog(Messages.getMessage("PdfViewerDecodeWait.message"));
	}
	
	
	
	/** move back one page */
	private void back(int count) {
		
		if (!commonValues.isProcessing()) { //lock to stop multiple accesses
			
			/**
			 * if in range update count and decode next page. Decoded pages are
			 * cached so will redisplay almost instantly
			 */
			int updatedTotal=commonValues.getCurrentPage()-count;
			if (updatedTotal >= 1) {
				commonValues.setCurrentPage(updatedTotal);
				
				currentGUI.resetStatusMessage("loading page "+commonValues.getCurrentPage());
				
				/** reset as rotation may change! */
				decode_pdf.setPageParameters(currentGUI.getScaling(), commonValues.getCurrentPage());
				
				//would reset scaling on page change to default
				//currentGUI.setScalingToDefault(); //set to 100%
				
				currentGUI.decodePage(false);
				
				//if scaling to window reset screen to fit rotated page
				if(currentGUI.getSelectedComboIndex(Commands.SCALING)<3)
					currentGUI.zoom();
				
			}
		}else
			currentGUI.showMessageDialog(Messages.getMessage("PdfViewerDecodeWait.message")); 
	}
	
	public void gotoPage(String page) {
		int newPage;
		
		//allow for bum values
		try{
			newPage=Integer.parseInt(page);
			
			if((newPage>decode_pdf.getPageCount())|(newPage<1)){
				currentGUI.showMessageDialog(Messages.getMessage("PdfViewerPageLabel.text")+ " "+
						page+" "+Messages.getMessage("PdfViewerOutOfRange.text")+" "+decode_pdf.getPageCount());
				newPage=commonValues.getCurrentPage();
				currentGUI.setPageNumber();
			}
			
		}catch(Exception e){
			currentGUI.showMessageDialog(">"+page+ "< "+Messages.getMessage("PdfViewerInvalidNumber.text")); 
			newPage=commonValues.getCurrentPage();
			currentGUI.pageCounter2.setText(""+commonValues.getCurrentPage()); 
		}
		
		//open new page
		if((!commonValues.isProcessing())&&(commonValues.getCurrentPage()!=newPage)){
			commonValues.setCurrentPage(newPage);
			currentGUI.decodePage(false);
			currentGUI.zoom();
		}
	}
	
	
	private void open(final String file) {
		
		boolean isURL = file.startsWith("http:");
		try {
			
			if(!isURL){
				commonValues.setFileSize(new File(file).length() >> 10);
			}
			
			commonValues.setSelectedFile(file);
			currentGUI.setViewerTitle(null);
			
		} catch (Exception e) {
			LogWriter.writeLog("Exception " + e + " getting paths");
		}
		
		/** check file exists */
		File testFile = new File(commonValues.getSelectedFile());
		if (!isURL && !testFile.exists()) {
			currentGUI.showMessageDialog(Messages.getMessage("PdfViewerFile.text") + commonValues.getSelectedFile() + Messages.getMessage("PdfViewerNotExist"));
			
			/** open the file*/
		} else if ((commonValues.getSelectedFile() != null) && (commonValues.isProcessing() == false)) {
			
			/** if running terminate first */
			thumbnails.terminateDrawing();
			
			decode_pdf.flushObjectValues(true);
			
			//reset the viewableArea before opening a new file
			decode_pdf.resetViewableArea();
			
			//<start-13>
			thumbnails.removeComponentListener();
			//<end-13>
			
			SwingWorker worker = new SwingWorker() {
				public Object construct() {
					if(!isOpening){
						isOpening=true;
						openFile(commonValues.getSelectedFile());
						isOpening=false;
					}
					return null;
				}
			};
			worker.start();
			
		}
	}
	
	private void updateRecentDocuments(String[] recentDocs) {
		if(recentDocs == null)
			return;
		
		for(int i=0; i<recentDocs.length;i++){
			if(recentDocs[i] != null){
				String shortenedFileName = recent.getShortenedFileName(recentDocs[i]);
				
				recentDocuments[i].setText(i+1 + ": " + shortenedFileName);
				if(recentDocuments[i].getText().equals(i+1 + ": "))
					recentDocuments[i].setVisible(false);
				else
					recentDocuments[i].setVisible(true);
				recentDocuments[i].setName(recentDocs[i]);
			}
		}
	}
	
	
	protected void recentDocumentsOption(JMenu file) {
		String[] recentDocs=properties.getRecentDocuments();
		if(recentDocs == null)
			return;
		
		for(int i=0;i<noOfRecentDocs;i++){
			
			if(recentDocs[i]==null)
				recentDocs[i]="";
			
			String fileNameToAdd=recentDocs[i];
			String shortenedFileName = recent.getShortenedFileName(fileNameToAdd);
			
			recentDocuments[i] = new JMenuItem(i+1 + ": " + shortenedFileName);
			if(recentDocuments[i].getText().equals(i+1 + ": "))
				recentDocuments[i].setVisible(false);
			recentDocuments[i].setName(fileNameToAdd);
			recentDocuments[i].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					
					if(currentPrinter.isPrinting())
						currentGUI.showMessageDialog(Messages.getMessage("PdfViewerPrintWait.message"));
					else if(commonValues.isProcessing() || isOpening)
						currentGUI.showMessageDialog(Messages.getMessage("PdfViewerDecodeWait.message"));
					else{
						//<start-forms>
						/**
						 * warn user on forms
						 */
						handleUnsaveForms();
						//<end-forms>
						
						JMenuItem item = (JMenuItem)e.getSource();
						String fileName = item.getName();
						
						if (!fileName.equals(""))
							open(fileName);
					}
				}
			});
			file.add(recentDocuments[i]);
		}
	}
	
	
	
	private void saveFile() {	
		
		/**
		 * create the file chooser to select the file
		 */
		File file=null;
		String fileToSave="";
		boolean finished=false;
		
		while(!finished){
			JFileChooser chooser = new JFileChooser(commonValues.getInputDir());
			chooser.setSelectedFile(new File(commonValues.getInputDir()+"/"+commonValues.getSelectedFile()));
			chooser.addChoosableFileFilter(new FileFilterer(new String[]{"pdf"}, "Pdf (*.pdf)"));
			chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			
			//set default name to current file name 
			int approved=chooser.showSaveDialog(null);
			if(approved==JFileChooser.APPROVE_OPTION){
				
				FileInputStream fis=null;
				FileOutputStream fos=null;
				
				file = chooser.getSelectedFile();
				fileToSave=file.getAbsolutePath();
				
				if(!fileToSave.endsWith(".pdf")){
					fileToSave += ".pdf";
					file=new File(fileToSave);
				}
				
				if(fileToSave.equals(commonValues.getSelectedFile()))
					return;
				
				if(file.exists()){
					int n=currentGUI.showConfirmDialog(fileToSave+"\n" +
							"The file already exisits.\n" +
							"Replace the existing file?","Resave Forms Data",JOptionPane.YES_NO_OPTION);
					if(n==1)
						continue;
				}
				
				try {
					fis=new FileInputStream(commonValues.getSelectedFile());
					fos=new FileOutputStream(fileToSave);
					
					byte[] buffer=new byte[4096];
					int bytes_read;
					
					while((bytes_read=fis.read(buffer))!=-1)
						fos.write(buffer,0,bytes_read);
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}
				
				try{
					fis.close();
					fos.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
				
				finished=true;
			}else{
				return;
			}
		}
	}
	
	/**Clean up and exit program*/
	private void exit() {
		
		thumbnails.stopProcessing();
		
		//<start-forms>
		/**
		 * warn user on forms
		 */
		handleUnsaveForms();
		//<end-forms>
		
		/**
		 * create the dialog
		 */
		currentGUI.showConfirmDialog(new JLabel(Messages.getMessage("PdfViewerExiting")),
				Messages.getMessage("PdfViewerprogramExit"), 
				JOptionPane.DEFAULT_OPTION,
				JOptionPane.PLAIN_MESSAGE);
		
		/**cleanup*/
		decode_pdf.closePdfFile();
		
		flush();
		
		//@exit
		System.exit(1);
	}
	
	/**
	 * routine to remove all objects from temp store
	 */
	public final void flush() {
		
		String target=commonValues.getTarget();

        if(target!=null){
            //get contents

            File temp_files = new File(target);
            String[] file_list = temp_files.list();
            if (file_list != null) {
                for (int ii = 0; ii < file_list.length; ii++) {
                    File delete_file = new File(target + commonValues.getSeparator()+file_list[ii]);
                    delete_file.delete();
                }
            }

        }
	}
}
