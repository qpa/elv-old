/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * Project Lead:  Mark Stephens (mark@idrsolutions.com)
 *
 * (C) Copyright 2006, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 *
 * ---------------
 * SimpleViewer.java
 * ---------------
 *
 * Original Author:  Mark Stephens (mark@idrsolutions.com)
 * Contributor(s):
 *
 */

package org.jpedal.examples.simpleviewer;

import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.JMenu;
import javax.swing.UIManager;

import org.jpedal.PdfDecoder;

import org.jpedal.examples.simpleviewer.gui.GUIFactory;
import org.jpedal.examples.simpleviewer.gui.SwingGUI;
import org.jpedal.examples.simpleviewer.gui.generic.GUIMouseHandler;
import org.jpedal.examples.simpleviewer.gui.generic.GUISearchWindow;
import org.jpedal.examples.simpleviewer.gui.generic.GUIThumbnailPanel;

import org.jpedal.examples.simpleviewer.gui.swing.SwingSearchWindow;
import org.jpedal.examples.simpleviewer.gui.swing.SwingMouseHandler;
import org.jpedal.examples.simpleviewer.gui.swing.SwingThumbnailPanel;
import org.jpedal.examples.simpleviewer.utils.Messages;
import org.jpedal.examples.simpleviewer.utils.Printer;
import org.jpedal.examples.simpleviewer.utils.PropertiesFile;

import org.jpedal.exception.PdfException;
import org.jpedal.exception.PdfFontException;
import org.jpedal.utils.LogWriter;
import org.w3c.dom.Node;

/**
 * Scope:<b>(All)</b>
 * <br>Description: Demo to show JPedal being used as a GUI viewer,
 * and to demonstrate some of JPedal's capabilities
 *
 *
 * <br>This class provides the framework for the Viewer and calls other classes which provide the following
 * functions:-
 *
 * <br>Values commonValues - repository for general settings
 * Printer currentPrinter - All printing functions and access methods to see if printing active
 * PdfDecoder decode_pdf - PDF library and panel
 * ThumbnailPanel thumbnails - provides a thumbnail pane down the left side of page - thumbnails can be clicked on to goto page
 * PropertiesFile properties - saved values stored between sessions
 * SwingGUI currentGUI - all Swing GUI functions
 * SearchWindow searchFrame (not GPL) - search Window to search pages and goto references on any page
 * Commands currentCommands - parses and executes all options
 * SwingMouseHandler mouseHandler - handles all mouse and related activity
 */
public class SimpleViewer {

	/**repository for general settings*/
	protected Values commonValues=new Values();

	/**All printing functions and access methods to see if printing active*/
	protected Printer currentPrinter=new Printer();

	/**PDF library and panel*/
	final protected PdfDecoder decode_pdf = new PdfDecoder(); //USE THIS FOR THE VIEWER ONLY
	/**/

	/**encapsulates all thumbnail functionality - just ignore if not required*/
	protected GUIThumbnailPanel thumbnails=new SwingThumbnailPanel(commonValues,decode_pdf);

	/**values saved on file between sessions*/
	private PropertiesFile properties=new PropertiesFile();

	/**general GUI functions*/
	protected SwingGUI currentGUI=new SwingGUI(decode_pdf,commonValues,thumbnails,properties);

	/**search window and functionality*/
	private GUISearchWindow searchFrame=new SwingSearchWindow(commonValues,currentGUI,decode_pdf);

	/**command functions*/
	protected Commands currentCommands=new Commands(commonValues,currentGUI,decode_pdf,
			thumbnails,properties,searchFrame,currentPrinter);

	/**all mouse actions*/
	protected GUIMouseHandler mouseHandler=new SwingMouseHandler(decode_pdf,currentGUI,commonValues,currentCommands);

	/**scaling values which appear onscreen*/
	protected String[] scalingValues;


	/**
	 * setup and run client, loading defaultFile on startup
	 */
	public void setupViewer(String defaultFile) {

		setupViewer();

		openDefaultFile(defaultFile);

	}

	/**
	 * open the file passed in by user on startup (do not call directly)
	 */
	private void openDefaultFile(String defaultFile) {

		//get any user set dpi
		String hiresFlag=System.getProperty("hires");
		if(hiresFlag!=null)
			commonValues.setUseHiresImage(true);

		//get any user set dpi
		String memFlag=System.getProperty("memory");
		if(memFlag!=null)
			commonValues.setUseHiresImage(false);

		//reset flag
		thumbnails.resetToDefault();

		commonValues.maxViewY=0;// ensure reset for any viewport

		/**
		 * open any default file and selected page
		 */
		if(defaultFile!=null){

			File testExists=new File(defaultFile);
			boolean isURL=false;
			if(defaultFile.startsWith("http:")){
				LogWriter.writeLog("Opening http connection");
				isURL=true;
			}

			if((!isURL) && (!testExists.exists())){
				currentGUI.showMessageDialog(defaultFile+"\n"+Messages.getMessage("PdfViewerdoesNotExist.message"));
			}else if((!isURL) &&(testExists.isDirectory())){
				currentGUI.showMessageDialog(defaultFile+"\n"+Messages.getMessage("PdfViewerFileIsDirectory.message"));
			}else{

				commonValues.setSelectedFile(defaultFile);
				commonValues.setFileSize(testExists.length() >> 10);

				currentGUI.setViewerTitle(null);

				/**see if user set Page*/
				String page=System.getProperty("Page");
				String bookmark=System.getProperty("Bookmark");
				if(page!=null){

					try{
						int pageNum=Integer.parseInt(page);

						if(pageNum<1){
							pageNum=-1;
							System.err.println(page+ " must be 1 or larger. Opening on page 1");
							LogWriter.writeLog(page+ " must be 1 or larger. Opening on page 1");
						}

						if(pageNum!=-1)
							openFile(testExists,pageNum);


					}catch(Exception e){
						System.err.println(page+ "is not a valid number for a page number. Opening on page 1");
						LogWriter.writeLog(page+ "is not a valid number for a page number. Opening on page 1");
					}
				}else if(bookmark!=null){
					openFile(testExists,bookmark);
				}else
					currentCommands.openFile(defaultFile);

			}
		}
	}

	/**
	 * setup and run client
	 */
	public SimpleViewer() {}

	/**
	 * setup and run client passing in paramter to show if
	 * running as applet, webstart or JSP (only applet has any effect
	 * at present)
	 */
	public SimpleViewer(int modeOfOperation) {

		commonValues.setModeOfOperation(modeOfOperation);

	}

	/**
	 * initialise and run client (default as Application in own Frame)
	 */
	public void setupViewer() {

		/**switch on thumbnails if flag set*/
		String setThumbnail=System.getProperty("thumbnail");
		if((setThumbnail!=null)&&(setThumbnail.equals("true")))
			thumbnails.setThumbnailsEnabled();

		/**non-GUI initialisation*/
		init(null);

		/**
		 * gui setup
		 */
		currentGUI.init(scalingValues,currentCommands,currentPrinter);

		setupButtonsAndMenus();

		mouseHandler.setupMouse();

		/**
		 * setup window for warning if renderer has problem
		 */
		decode_pdf.setMessageFrame(currentGUI.getFrame());

		boolean showFirstTimePopup = properties.getValue("showfirsttimepopup").equals("true");
		if((showFirstTimePopup)&&(!PdfDecoder.runningAsFreeApplication())){
			currentGUI.showFirstTimePopup();
			properties.setValue("showfirsttimepopup","false");
		}


		/**
		 * check for itext and tell user about benefits
		 */
		if(!commonValues.isContentExtractor()){
			boolean showItextMessage = properties.getValue("showitextmessage").equals("true");

			if (!commonValues.isItextOnClasspath() && showItextMessage) {

				currentGUI.showItextPopup();

				properties.setValue("showitextmessage","false");
			}
		}
	}

	/**
	 * setup the viewer
	 */
	protected void init(ResourceBundle bundle) {

        /**
		 * allow user to define country and language settings
		 */

		//Locale aLocale = new Locale("en", "EN");

		//Locale.setDefault(aLocale);


		/**
		 * load correct set of messages
		 */
		if(bundle==null){
			try{
				Messages.setBundle(ResourceBundle.getBundle("org.jpedal.international.messages"));
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Exception loading resource bundle");
			}
		}else
			Messages.setBundle(bundle);

		/**setup scaling values which ar displayed for user to choose*/
        this.scalingValues= new String[]{Messages.getMessage("PdfViewerScaleWindow.text"),Messages.getMessage("PdfViewerScaleHeight.text"),
                Messages.getMessage("PdfViewerScaleWidth.text"),
                "25","50","75","100","125","150","200","250","500","750","1000"};

		/**debugging code to create a log*
		LogWriter.setupLogFile(true,1,"","v",false);
		//LogWriter.log_name =  "/mnt/shared/log.txt";
		/**/


		//if you wish to add your own annots code, use either example below and remembet to
		//call decode_pdf.setAnnotationsVisible(false);
		/**
		 * ANNOTATIONS code 1
		 *
		 * use for annotations, loading icons and enabling display of annotations
		 * this enables general annotations with an icon for each type.
		 * See below for more specific function.
		 */

		//<start-forms>
		if(!decode_pdf.showAnnotations)
			decode_pdf.createPageHostspots(currentGUI.getAnnotTypes(),"org/jpedal/examples/simpleviewer/annots/");
		//<end-forms>

		/**
		 * ANNOTATIONS code 2
		 *
		 * this code allows you to create a unique set on icons for any type of annotations, with
		 * an icons for every annotation, not just types.
		 */
		//currentGUI.createUniqueAnnontationIcons();


		/**/
		/**
		 * FONT EXAMPLE CODE showing JPedal's functionality to set values for
		 * non-embedded fonts.
		 *
		 * This allows sophisticated substitution of non-embedded fonts.
		 *
		 * Most font mapping is done as the fonts are read, so these calls must
		 * be made BEFORE the openFile() call.
		 */

		/**
		 * FONT EXAMPLE - Replace global default for non-embedded fonts.
		 *
		 * You can replace Lucida as the standard font used for all non-embedded and substituted fonts
		 * by using is code.
		 * Java fonts are case sensitive, but JPedal resolves currentGUI.frame, so you could
		 * use Webdings, webdings or webDings for Java font Webdings
		 */
		try{
			//choice of example font to stand-out (useful in checking results to ensure no font missed.
			//In general use Helvetica or similar is recommended
			decode_pdf.setDefaultDisplayFont("SansSerif");
		}catch(PdfFontException e){ //if its not available catch error and show valid list

			System.out.println(e.getMessage());

			//get list of fonts you can use
			String[] fontList =GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
			System.out.println(Messages.getMessage("PdfViewerFontsFound.message"));
			System.out.println("=====================\n");
			int count = fontList.length;
			for (int i = 0; i < count; i++) {
				Font f=new Font(fontList[i],1,10);
				System.out.println(fontList[i]+" ("+Messages.getMessage("PdfViewerFontsPostscript.message")+"="+f.getPSName()+")");

			}
			System.exit(1);

		}/***/

		/**
		 * IMPORTANT note on fonts for EXAMPLES
		 *
		 * USEFUL TIP : The SimpleViewer displays a list of fonts used on the
		 * current PDF page with the File > Fonts menu option.
		 *
		 * PDF allows the use of weights for fonts so Arial,Bold is a weight of
		 * Arial. This value is not case sensitive so JPedal would regard
		 * arial,bold and aRiaL,BoLd as the same.
		 *
		 * Java supports a set of Font families internally (which may have
		 * weights), while JPedals substitution facility uses physical True Type
		 * fonts so it is resolving each font weight separately. So mapping
		 * works differently, depending on which is being used.
		 *
		 * If you are using a font, which is named as arial,bold you can use
		 * either arial,bold or arial (and JPedal will then try to select the
		 * bold weight if a Java font is used).
		 *
		 * So for a font such as Arial,Bold JPedal will test for an external
		 * truetype font substitution (ie arialMT.ttf) mapped to Arial,Bold. BUT
		 * if the substitute font is a Java font an additional test will be made
		 * for a match against Arial if there is no match on Arial,Bold.
		 *
		 * If you want to map all Arial to equivalents to a Java font such as
		 * Times New Roman, just map Arial to Times New Roman (only works for
		 * inbuilt java fonts). Note if you map Arial,Bold to a Java font such
		 * as Times New Roman, you will get Times New Roman in a bold weight, if
		 * available. You cannot set a weight for the Java font.
		 *
		 * If you wish to substitute Arial but not Arial,Bold you should
		 * explicitly map Arial,Bold to Arial,Bold as well.
		 *
		 * The reason for the difference is that when using Javas inbuilt fonts
		 * JPedal can resolve the Font Family and will try to work out the
		 * weight internally. When substituting Truetype fonts, these only
		 * contain ONE weight so JPedal is resolving the Font and any weight as
		 * a separate font . Different weights will require separate files.
		 *
		 * Open Source version does not support all font capabilities.
		 */


		/**
		 * FONT EXAMPLE - Use Standard Java fonts for substitution
		 *
		 * This code tells JPedal to substitute fonts which are not embedded.
		 *
		 * The Name is not case-sensitive.
		 *
		 * Spaces are important so TimesNewRoman and Times New Roman are
		 * degarded as 2 fonts.
		 *
		 * If you have 2 copies of arialMT.ttf in the scanned directories, the
		 * last one will be used.
		 *
		 *
		 * If you wish to use one of Javas fonts for display (for example, Times
		 * New Roman is a close match for myCompanyFont in the PDF, you can the
		 * code below
		 *
		 * String[] aliases={"Times New Roman"};//,"helvetica","arial"};
		 * decode_pdf.setSubstitutedFontAliases("myCompanyFont",aliases);
		 *
		 * Here is is used to map Javas Times New Roman (and all weights) to
		 * TimesNewRoman.
		 *
		 * This can also be done with the command -TTfontMaps="TimesNewRoman=Times New Roman","font2=pdfFont1"
		 */		
		//String[] nameInPDF={"TimesNewRoman"};//,"helvetica","arial"};
		//decode_pdf.setSubstitutedFontAliases("Times New Roman",nameInPDF);

    }

	/**
	 * sets up all the toolbar items
	 */
	private void setupButtonsAndMenus() {

		createSwingMenu(true);

		/**
		 * combo boxes on toolbar
		 * */
		currentGUI.addCombo(Messages.getMessage("PdfViewerTooltip.scaling"), Messages.getMessage("PdfViewerTooltip.zoomin"), Commands.SCALING);

		currentGUI.addCombo(Messages.getMessage("PdfViewerRotation.text"), Messages.getMessage("PdfViewerTooltip.rotation"), Commands.ROTATION);

		/**image quality option - allow user to choose between images downsampled
		 * (low memory usage 72 dpi) image hires (high memory usage no downsampling)*/
		currentGUI.addCombo("Image Optimisation",Messages.getMessage("PdfViewerTooltip.image"),Commands.QUALITY);

		createButtons();

		currentGUI.addCursor();

		/**status object on toolbar showing 0 -100 % completion */
		currentGUI.initStatus();


	}

	/**
	 * setup up the buttons
	 * (add your own here if required)
	 */
	private void createButtons() {

		currentGUI.addButton(GUIFactory.BUTTONBAR,Messages.getMessage("PdfViewerTooltip.open"),"/org/jpedal/examples/simpleviewer/res/open.gif",Commands.OPENFILE);

		currentGUI.addButton(GUIFactory.BUTTONBAR,Messages.getMessage("PdfViewerPrint.tip"),"/org/jpedal/examples/simpleviewer/res/print.gif",Commands.PRINT);

		currentGUI.addButton(GUIFactory.BUTTONBAR,"","/org/jpedal/examples/simpleviewer/res/bookmarks.gif",Commands.BOOKMARK);


		currentGUI.addButton(GUIFactory.BUTTONBAR,Messages.getMessage("PdfViewer.propsMessage"),"/org/jpedal/examples/simpleviewer/res/properties.gif",Commands.DOCINFO);

		currentGUI.addButton(GUIFactory.BUTTONBAR,Messages.getMessage("PdfViewerTooltip.about"),"/org/jpedal/examples/simpleviewer/res/about.gif",Commands.INFO);


		/**
		 * external/itext button option example adding new option to Export menu
		 * an icon is set wtih location on classpath
		 * "/org/jpedal/examples/simpleviewer/res/newfunction.gif"
		 * Make sure it exists at location and is copied into jar if recompiled
		 */
		//currentGUI.addButton(currentGUI.BUTTONBAR,tooltip,"/org/jpedal/examples/simpleviewer/res/newfunction.gif",Commands.NEWFUNCTION);

		/**
		 * external/itext menu option example adding new option to Export menu
		 * Tooltip text can be externalised in Messages.getMessage("PdfViewerTooltip.NEWFUNCTION")
		 * and text added into files in res package
		 */


	}

	/**
	 * create items on drop down menus
	 */
	protected void createSwingMenu(boolean includeAll) {

		JMenu fileMenuList = new JMenu(Messages.getMessage("PdfViewerFile.text"));
		currentGUI.addToMainMenu(fileMenuList);

		JMenu view = new JMenu(Messages.getMessage("PdfViewerView.text"));
		currentGUI.addToMainMenu(view);

		JMenu goTo = new JMenu(Messages.getMessage("PdfViewerGoto.text"));
		view.add(goTo);

		currentGUI.addMenuItem(goTo,Messages.getMessage("PdfViewerGoto.FirstPage"),"",Commands.FIRSTPAGE);
		currentGUI.addMenuItem(goTo,Messages.getMessage("PdfViewerGoto.BackPage"),"",Commands.BACKPAGE);
		currentGUI.addMenuItem(goTo,Messages.getMessage("PdfViewerGoto.ForwardPage"),"",Commands.FORWARDPAGE);
		currentGUI.addMenuItem(goTo,Messages.getMessage("PdfViewerGoto.LastPage"),"",Commands.LASTPAGE);
		currentGUI.addMenuItem(goTo,Messages.getMessage("PdfViewerGoto.GoTo"),"",Commands.GOTO);

		goTo.addSeparator();

		if(includeAll){

			currentGUI.addMenuItem(goTo,Messages.getMessage("PdfViewerGoto.PreviousDoucment"),"",Commands.PREVIOUSDOCUMENT);
			currentGUI.addMenuItem(goTo,Messages.getMessage("PdfViewerGoto.NextDoucment"),"",Commands.NEXTDOCUMENT);

			/**
			 * add export menus
			 **/
			JMenu export = new JMenu(Messages.getMessage("PdfViewerTooltip.ExportMenu"));
			currentGUI.addToMainMenu(export);


			if(commonValues.isItextOnClasspath()){
				JMenu pdf = new JMenu("PDF");
				export.add(pdf);

				currentGUI.addMenuItem(pdf,"One Per Page",Messages.getMessage("PdfViewerTooltip.PDFExport"),Commands.PDF);

				//<start-13>
				JMenu pageTools = new JMenu(Messages.getMessage("PdfViewerTooltip.PageTools"));
				currentGUI.addToMainMenu(pageTools);

				currentGUI.addMenuItem(pageTools,Messages.getMessage("PdfViewerTooltip.ROTATE"),"",Commands.ROTATE);
				currentGUI.addMenuItem(pageTools,Messages.getMessage("PdfViewerTooltip.DELETE"),"",Commands.DELETE);
				currentGUI.addMenuItem(pageTools,Messages.getMessage("PdfViewerTooltip.ADD"),"",Commands.ADD);
				currentGUI.addMenuItem(pageTools,Messages.getMessage("PdfViewerTooltip.ADDHEADERFOOTER"),"",Commands.ADDHEADERFOOTER);
				currentGUI.addMenuItem(pageTools,Messages.getMessage("PdfViewerTooltip.STAMPTEXT"),"",Commands.STAMPTEXT);
				currentGUI.addMenuItem(pageTools,Messages.getMessage("PdfViewerTooltip.STAMPIMAGE"),"",Commands.STAMPIMAGE);
				currentGUI.addMenuItem(pageTools,Messages.getMessage("PdfViewerTooltip.SETCROP"),"",Commands.SETCROP);
				//<end-13>
			}

			/**
			 * external/itext menu option example adding new option to Export menu
			 */
			//currentGUI.addMenuItem(export,"NEW",tooltip,Commands.NEWFUNCTION);
			/**
			 * external/itext menu option example adding new option to Export menu
			 * Tooltip text can be externalised in Messages.getMessage("PdfViewerTooltip.NEWFUNCTION")
			 * and text added into files in res package
			 */

			currentGUI.addMenuItem(export,"Bitmap",Messages.getMessage("PdfViewerTooltip.bitmapExport"),Commands.BITMAP);



		}

		currentGUI.addMenuItem(view,Messages.getMessage("PdfViewerTitle.autoscroll"),Messages.getMessage("PdfViewerTooltip.autoscroll"),Commands.AUTOSCROLL);


		/**
		 * add open options
		 **/
		JMenu Open = new JMenu(Messages.getMessage("PdfViewerOpen.text"));
		fileMenuList.add(Open);

		currentGUI.addMenuItem(Open,Messages.getMessage("PdfViewerOpen.text"),Messages.getMessage("PdfViewerTooltip.open"),Commands.OPENFILE);
		currentGUI.addMenuItem(Open,Messages.getMessage("PdfViewerOpenurl.text"),Messages.getMessage("PdfViewerTooltip.openurl"),Commands.OPENURL);

		fileMenuList.addSeparator();

		if(includeAll)
			currentGUI.addMenuItem(fileMenuList,Messages.getMessage("PdfViewerSave.text"),
					Messages.getMessage("PdfViewerTooltip.save"),Commands.SAVE);

		//<start-forms>

	    if(commonValues.isItextOnClasspath()&&(decode_pdf.supportsEmbeddedFonts()))
			currentGUI.addMenuItem(fileMenuList,
					Messages.getMessage("PdfViewerMenu.saveForms"),
					Messages.getMessage("PdfViewerTooltip.saveForms"),
					Commands.SAVEFORM);

		//<end-forms>

		fileMenuList.addSeparator();

		currentGUI.addMenuItem(fileMenuList,"Document Properties",
				Messages.getMessage("PdfViewerMenu.props"),Commands.DOCINFO);

		fileMenuList.addSeparator();

		if(includeAll){
			currentGUI.addMenuItem(fileMenuList,Messages.getMessage("PdfViewerPrint.text"),
					Messages.getMessage("PdfViewerTooltip.print"),Commands.PRINT);

			fileMenuList.addSeparator();
		}

		if(includeAll)
			currentCommands.recentDocumentsOption(fileMenuList);

		fileMenuList.addSeparator();

		currentGUI.addMenuItem(fileMenuList,Messages.getMessage("PdfViewerExit.text"),
				Messages.getMessage("PdfViewerShutdown.text"),Commands.EXIT);

		if(includeAll){
			JMenu help = new JMenu(Messages.getMessage("PdfViewerHelp.text"));

			currentGUI.addToMainMenu(help);
			currentGUI.addMenuItem(help,Messages.getMessage("PdfViewerMenu.VisitWebsite"),"",Commands.VISITWEBSITE);
			currentGUI.addMenuItem(help,Messages.getMessage("PdfViewerMenu.about"),Messages.getMessage("PdfViewerTooltip.about"),Commands.INFO);
		}	
	}
	
	/** main method to run the software as standalone application */
	public static void main(String[] args) {
		
		/** 
		 * set the look and feel for the GUI components to be the
		 * default for the system it is running on
		 */
		try {
			UIManager.setLookAndFeel( UIManager.getSystemLookAndFeelClassName() );
		}catch (Exception e) { 
			LogWriter.writeLog("Exception " + e + " setting look and feel");
		}
		
		SimpleViewer current = new SimpleViewer();
		
		if (args.length > 0)
			current.setupViewer(args[0]);
		else 
			current.setupViewer();
		
	}
	
	/**
	 * General code to open file at specified boomark - do not call directly
	 *  
	 * @param file File the PDF to be decoded
	 * @param bookmark - if not present, exception will be thrown
	 */
	private void openFile(File file, String bookmark) {
		
		try{
			
			boolean fileCanBeOpened=currentCommands.openUpFile(file.getCanonicalPath());
			
			//reads tree and populates lookup table
			Node rootNode= decode_pdf.getOutlineAsXML().getFirstChild();
			Object bookmarkPage=null;
			if(rootNode!=null){
				
				//open page if bookmark found
				bookmarkPage=currentGUI.initPDFOutlines(rootNode,bookmark);
			}
			
			if(bookmarkPage==null)
				throw new PdfException("Unknown bookmark "+bookmark);
			
			int page=Integer.parseInt((String)bookmarkPage);
			commonValues.setCurrentPage(page);
			if(fileCanBeOpened)
				currentCommands.processPage();
			
		}catch(Exception e){
			System.err.println("Exception " + e + " processing file");
			
			
			commonValues.setProcessing(false);
		}
	}
	
	/**
	 * General code to open file at specified page - do not call directly
	 *  
	 * @param file File the PDF to be decoded
	 * @param page int page number to show the user
	 */
	private void openFile(File file, int page) {
		
		try{
			boolean fileCanBeOpened=currentCommands.openUpFile(file.getCanonicalPath());
			
			commonValues.setCurrentPage(page);
			
			if(fileCanBeOpened)
				currentCommands.processPage();
		}catch(Exception e){
			System.err.println("Exception " + e + " processing file"); 
			
			
			commonValues.setProcessing(false);
		}
	}	
}
