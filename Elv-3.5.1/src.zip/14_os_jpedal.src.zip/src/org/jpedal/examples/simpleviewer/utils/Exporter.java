/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * Project Lead:  Mark Stephens (mark@idrsolutions.com)
 *
 * (C) Copyright 2005, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 *
 * ---------------
 * Exporter.java
 * ---------------
 *
 * Original Author:  Mark Stephens (mark@idrsolutions.com)
 * Contributor(s):
 *
 */
package org.jpedal.examples.simpleviewer.utils;

import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
//<start-13>
import javax.imageio.ImageIO;
//<end-13>
import javax.media.jai.JAI;
import javax.swing.JOptionPane;
import javax.swing.ProgressMonitor;

import org.jpedal.PdfDecoder;

import org.jpedal.examples.simpleviewer.gui.GUIFactory;
import org.jpedal.examples.simpleviewer.gui.SwingGUI;
import org.jpedal.examples.simpleviewer.gui.popups.SaveBitmap;
import org.jpedal.exception.PdfException;
import org.jpedal.exception.PdfSecurityException;
import org.jpedal.io.ColorSpaceConvertor;
import org.jpedal.objects.PdfPageData;
import org.jpedal.utils.LogWriter;
import org.jpedal.utils.Strip;

/**provide save functions for SimpleViewer to write out text, images, etc*/
public class Exporter {
	
	final public static int RECTANGLE=1;
	final public static int WORDLIST=2;
	final public static int TABLE=3;
	
	/**file separator used*/
	private final String separator=System.getProperty( "file.separator" );
	
	private String fileName="";
	
	private GUIFactory currentGUI;
	
	private PdfDecoder dPDF;
	
	private String selectedFile;
	
	public Exporter(SwingGUI currentGUI,String selectedFile,PdfDecoder decode_pdf){
		String fileName = new File(selectedFile).getName();
		if(fileName.lastIndexOf(".") != -1)
			fileName = fileName.substring(0,fileName.lastIndexOf("."));
		
		StringBuffer fileNameBuffer = new StringBuffer(fileName);
		int index;
		while((index = fileNameBuffer.toString().indexOf("%20")) != -1){
			fileNameBuffer.replace(index,index+3," ");
		}
		
		this.fileName = fileNameBuffer.toString();
		this.currentGUI=currentGUI;
		this.selectedFile=selectedFile;
		this.dPDF=decode_pdf;
		
	}
	
	public void extractPagesAsImages(SaveBitmap current_selection) {
		//get user choice
		final int startPage = current_selection.getStartPage();
		final int endPage = current_selection.getEndPage();
		
		if(startPage < 1 || endPage < 1)
			return;
		
		final String format = current_selection.getPrefix();
		final int scaling=current_selection.getScaling();
		final String output_dir = current_selection.getRootDir()+separator+fileName+separator+"thumbnails"+separator;
		
		File testDirExists=new File(output_dir);
		if(!testDirExists.exists())
			testDirExists.mkdirs();
		
		final ProgressMonitor status = new ProgressMonitor(currentGUI.getFrame(),
				"Generating bitmaps of pages","",startPage,endPage);
		
		final SwingWorker worker = new SwingWorker() {
			
			public Object construct() {
				//do the save
				int count=0;
				boolean yesToAll = false;
				for(int page=startPage;page<endPage+1;page++){
					if(status.isCanceled()){
						currentGUI.showMessageDialog("Operation Canceled.\n" +
								count+" pages have been exported");
						return null;
					}
					BufferedImage image_to_save=null;
					try {
						image_to_save = dPDF.getPageAsImage(page);
					} catch (PdfException e1) {
						e1.printStackTrace();
					}
					
					if(image_to_save!=null){
						
						/** scale image with bicubic scaling*/
						if(scaling!=100){
							int newWidth=image_to_save.getWidth()*scaling/100;
							
							//only 1 new co-ord needed so use -1 for other as aspect ration does not change
							Image scaledImage= image_to_save.getScaledInstance(newWidth,-1,BufferedImage.SCALE_SMOOTH);
							image_to_save = new BufferedImage(scaledImage.getWidth(null),scaledImage.getHeight(null) , BufferedImage.TYPE_INT_RGB);
							Graphics2D g2 = image_to_save.createGraphics();
							g2.drawImage(scaledImage, 0, 0,null);
							
						}
						
						
						File fileToSave = new File(output_dir + page+"."+format);
		                if(fileToSave.exists() && !yesToAll){
		                	if((endPage - startPage) > 1){
		                		int n = currentGUI.showOverwriteDialog(fileToSave.getAbsolutePath(),true);
		                		
		                		if(n==0){
		                			// clicked yes so just carry on for this once
		                		}else if(n==1){
		                			// clicked yes to all, so set flag
		                			yesToAll = true;
		                		}else if(n==2){
		                			// clicked no, so loop round again
		                			status.setProgress(page);
		                			continue;
		                		}else{
		                			
		                			currentGUI.showMessageDialog("Operation Canceled.\n" +
		                					count+" pages have been exported");
		                			
		                			status.close();
		                			return null;
		                		}
		                	}else{
		                		int n = currentGUI.showOverwriteDialog(fileToSave.getAbsolutePath(),false);
		                		
		                		if(n==0){
		                			// clicked yes so just carry on
		                		}else{
		                			// clicked no, so exit
		                			return null;
		                		}
		                	}
		                }

						//save image
						boolean failed=dPDF.getObjectStore().saveStoredImage(
								output_dir + page,image_to_save,true,false,format);
					}
					
					count++;
					status.setProgress(page+1);
				}
				currentGUI.showMessageDialog("Pages saved as images to "+output_dir);
				return null;
			}
		};
		
		worker.start();
	}
	
	
	/**save image - different versions have different bugs for file formats so we use best for 
	 * each image type
	 * @param image_to_save
	 */
	private void saveImage(BufferedImage image_to_save, String fileName,String prefix) {
		//<start-13>
		if(prefix.indexOf("tif")!=-1){
			
			try {
				FileOutputStream os = new FileOutputStream(fileName);
				JAI.create("encode", image_to_save, os, "TIFF", null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			
		}else{ //default
			try {
				
				ImageIO.write(image_to_save,prefix,new File(fileName));
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		/**
		//<end-13>
		try {
			FileOutputStream os = new FileOutputStream(fileName);
			JAI.create("encode", image_to_save, os, "TIFF", null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		/**/
	}
	
}
