/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * Project Lead:  Mark Stephens (mark@idrsolutions.com)
 *
 * (C) Copyright 2005, IDRsolutions and Contributors.
 * 
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 *
 * ---------------
 * SwingGUI.java
 * ---------------
 * (C) Copyright 2006, by IDRsolutions and Contributors.
 *

 * Original Author:  Mark Stephens (mark@idrsolutions.com)
 * Contributor(s):
 *
 */
package org.jpedal.examples.simpleviewer.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.StringTokenizer;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.WindowConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.tree.DefaultMutableTreeNode;

import org.jpedal.PdfDecoder;
import org.jpedal.examples.simpleviewer.Commands;
import org.jpedal.examples.simpleviewer.Values;
import org.jpedal.examples.simpleviewer.gui.generic.GUIButton;
import org.jpedal.examples.simpleviewer.gui.generic.GUICombo;
import org.jpedal.examples.simpleviewer.gui.generic.GUIThumbnailPanel;
import org.jpedal.examples.simpleviewer.gui.popups.*;
import org.jpedal.examples.simpleviewer.gui.swing.CommandListener;
import org.jpedal.examples.simpleviewer.gui.swing.FrameCloser;
import org.jpedal.examples.simpleviewer.gui.swing.PageViewChanger;
import org.jpedal.examples.simpleviewer.gui.swing.SwingButton;
import org.jpedal.examples.simpleviewer.gui.swing.SwingCombo;
import org.jpedal.examples.simpleviewer.gui.swing.SwingMenuItem;
import org.jpedal.examples.simpleviewer.gui.swing.SwingOutline;
import org.jpedal.examples.simpleviewer.utils.BrowserLauncher;
import org.jpedal.examples.simpleviewer.utils.Messages;
import org.jpedal.examples.simpleviewer.utils.Printer;
import org.jpedal.examples.simpleviewer.utils.PropertiesFile;
import org.jpedal.examples.simpleviewer.utils.SwingWorker;
import org.jpedal.exception.PdfException;
import org.jpedal.io.StatusBar;
import org.jpedal.objects.PdfFileInformation;
import org.jpedal.objects.PdfPageData;
import org.jpedal.utils.LogWriter;
import org.jpedal.utils.repositories.Vector_Int;
import org.w3c.dom.Node;

/**
 * Scope:<b>(All)</b>
 * <br>Description: Swing GUI functions in Viewer
 * 
 *
 */
public class SwingGUI extends GUI implements GUIFactory {
	
	/**listener on buttons, menus, combboxes to execute options (one instance on all objects)*/
	private CommandListener currentCommandListener;	
	
	/**holds OPEN, INFO,etc*/
	private JToolBar topButtons = new JToolBar();
	
	/**holds rotation, quality, scaling and status*/
	private JToolBar comboBar = new JToolBar();
	
	/**holds back/forward buttons at bottom of page*/
	private JToolBar bottomNavButtons = new JToolBar();
	
	/**holds all menu entries (File, View, Help)*/
	private JMenuBar currentMenu =new JMenuBar();
	
	//<start-forms>
	/**tell user on first form change it can be saved*/
	private boolean firstTimeFormMessage=true;
	//<end-forms>
	
	/** visual display of current cursor co-ords on page*/
	private JLabel coords=new JLabel();
	
	/**root element to hold display*/
	private JFrame frame=new JFrame();
	
	/**displayed on left to hold thumbnails, bookmarks*/
	private JTabbedPane navOptionsPanel=new JTabbedPane();
	
	/**split display between PDF and thumbnails/bookmarks*/
	private JSplitPane displayPane;
	
	/**Scrollpane for pdf panel*/
	private JScrollPane scrollPane = new JScrollPane();
	
	private final Font headFont=new Font("SansSerif",Font.BOLD,14);
	
	private final Font textFont=new Font("Serif",Font.PLAIN,12);
	
	/**Interactive display object - needs to be added to PdfDecoder*/
	private StatusBar statusBar=new StatusBar(Color.orange);
	
	public JTextField pageCounter2 = new JTextField(4);
	
	private JLabel pageCounter3;

	private JLabel optimizationLabel;
	
	public SwingGUI(PdfDecoder decode_pdf,Values commonValues,GUIThumbnailPanel thumbnails,PropertiesFile properties){
		
		this.decode_pdf=decode_pdf;
		this.commonValues=commonValues;
		this.thumbnails=thumbnails;
		this.properties=properties;
		
		if(commonValues.isContentExtractor()){
			titleMessage="IDRsolutions Extraction Solution "+PdfDecoder.version+" ";
			showOutlines=false;
		}
	}
	
	/**used when clicking on thumbnails to move onto new page*/
	private class PageChanger implements ActionListener {
		
		int page;
		public PageChanger(int i){
			i++;
			page=i;
		}
		
		public void actionPerformed(ActionEvent e) {
			if((!commonValues.isProcessing())&&(commonValues.getCurrentPage()!=page)){
				commonValues.setCurrentPage(page);
				
				statusBar.resetStatus("");
				
				setScalingToDefault();
				
				decode_pdf.setPageParameters(getScaling(), commonValues.getCurrentPage());
				
				decodePage(false);
				
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#initLayoutMenus(javax.swing.JMenu, java.lang.String[], int[])
	 */
	public void initLayoutMenus(JMenu pageLayout, String[] descriptions, int[] value) {
		
		ButtonGroup group = new ButtonGroup();
		int count=value.length;
		for(int i=0;i<count;i++){
			
			JCheckBoxMenuItem pageView=new JCheckBoxMenuItem(descriptions[i]);
			pageView.setBorder(BorderFactory.createEmptyBorder());
			group.add(pageView);
			if(i==0)
				pageView.setSelected(true);
			
			pageView.addActionListener(new PageViewChanger(value[i],decode_pdf));
			pageLayout.add(pageView);	
		}
	}
	
	/**
	 * show fonts displayed
	 */
	private JScrollPane getFontInfoBox(){
		
		JPanel details=new JPanel();
		
		JScrollPane scrollPane=new JScrollPane();
		scrollPane.setPreferredSize(new Dimension(400,300));
		scrollPane.getViewport().add(details);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		details.setOpaque(true);
		details.setBackground(Color.white);
		details.setEnabled(false);
		//<start-13>
		details.setLayout(new BoxLayout(details, BoxLayout.PAGE_AXIS));
		//<end-13>
		
		/**
		 * list of fonts
		 */
		String xmlText=decode_pdf.getFontsInFile();
		if(xmlText.length()>0){
			
			JTextArea xml=new JTextArea();
			xml.setLineWrap(false);
			xml.setText(xmlText);
			details.add(xml);
			xml.setCaretPosition(0);
			xml.setOpaque(false);
			
			details.add(Box.createRigidArea(new Dimension(0,5)));
		}
		
		return scrollPane;
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#getInfoBox()
	 */
	public void getInfoBox() {
		
		final JPanel details=new JPanel();
		details.setPreferredSize(new Dimension(400,260));
		details.setOpaque(false);
		//<start-13>
		details.setLayout(new BoxLayout(details, BoxLayout.Y_AXIS));
		//<end-13>
		
		//general details
		JLabel header1=new JLabel(Messages.getMessage("PdfViewerInfo.title")); 
		header1.setOpaque(false);
		header1.setFont(headFont);
		header1.setAlignmentX(Component.CENTER_ALIGNMENT);
		details.add(header1);
		
		details.add(Box.createRigidArea(new Dimension(0,15)));
		
		String xmlText=Messages.getMessage("PdfViewerInfo1")+Messages.getMessage("PdfViewerInfo2");
		if(xmlText.length()>0){
			
			JTextArea xml=new JTextArea();
			xml.setOpaque(false);
			xml.setText(xmlText + "\n\nVersion: "+PdfDecoder.version);
			xml.setLineWrap(true);
			xml.setWrapStyleWord(true);
			xml.setEditable(false);
			details.add(xml);
			xml.setAlignmentX(Component.CENTER_ALIGNMENT);
			
		}
		
		ImageIcon logo=new ImageIcon(getClass().getResource("/org/jpedal/examples/simpleviewer/res/logo.gif"));
		details.add(Box.createRigidArea(new Dimension(0,25)));
		JLabel idr=new JLabel(logo);
		idr.setAlignmentX(Component.CENTER_ALIGNMENT);
		details.add(idr);
		
		final JLabel url=new JLabel("<html>http://www.jpedal.org");
		url.setForeground(Color.blue);
		url.setHorizontalAlignment(JLabel.CENTER);
		url.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		url.addMouseListener(new MouseListener() {
			public void mouseEntered(MouseEvent e) {
				details.setCursor(new Cursor(Cursor.HAND_CURSOR));
				url.setText("<html><a href=http://www.jpedal.org>http://www.jpedal.org</a>");
			}
			
			public void mouseExited(MouseEvent e) {
				details.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
				url.setText("<html>http://www.jpedal.org");
			}
			
			public void mouseClicked(MouseEvent e) {
				try {
					BrowserLauncher.openURL("http://www.jpedal.org");
				} catch (IOException e1) {
					showMessageDialog("Unable to launch browser");
				}
			}
			
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
		});				
		
		details.add(url);
		details.add(Box.createRigidArea(new Dimension(0,5)));
		
		details.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		showMessageDialog(details,Messages.getMessage("PdfViewerInfo3"),JOptionPane.PLAIN_MESSAGE); 
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#resetRotationBox()
	 */
	public void resetRotationBox() {
		
		PdfPageData currentPageData=decode_pdf.getPdfPageData();
		rotation=currentPageData.getRotation(commonValues.getCurrentPage());
		if(getSelectedComboIndex(Commands.ROTATION)!=(rotation/90)){
			setSelectedComboIndex(Commands.ROTATION, (rotation/90));
		}else{
			decode_pdf.repaint();
		}
	}
	
	
	/**
	 * show document properties
	 */
	private JScrollPane getPropertiesBox(String selectedFile, String inputDir, long size, int pageCount,int currentPage) {
		
		PdfFileInformation currentFileInformation=decode_pdf.getFileInformationData();
		
		/**get the Pdf file information object to extract info from*/
		if(currentFileInformation!=null){
			
			JPanel details=new JPanel();
			details.setOpaque(true);
			details.setBackground(Color.white);
			//<start-13>
			details.setLayout(new BoxLayout(details, BoxLayout.Y_AXIS));
			//<end-13>
			
			JScrollPane scrollPane=new JScrollPane();
			scrollPane.setPreferredSize(new Dimension(400,300));
			scrollPane.getViewport().add(details);
			scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			
			//general details
			JLabel header1=new JLabel(Messages.getMessage("PdfViewerGeneral")); 
			header1.setFont(headFont);
			header1.setOpaque(false);
			details.add(header1);
			
			JLabel g1=new JLabel(Messages.getMessage("PdfViewerFileName")+selectedFile);
			g1.setFont(textFont);
			g1.setOpaque(false);
			details.add(g1);
			
			JLabel g2=new JLabel(Messages.getMessage("PdfViewerFilePath")+inputDir); 
			g2.setFont(textFont);
			g2.setOpaque(false);
			details.add(g2);
			
			JLabel g3=new JLabel(Messages.getMessage("PdfViewerFileSize")+size+" K");
			g3.setFont(textFont);
			g2.setOpaque(false);
			details.add(g3);
			
			JLabel g4=new JLabel(Messages.getMessage("PdfViewerPageCount")+pageCount); 
			g4.setOpaque(false);
			g4.setFont(textFont);
			details.add(g4);
			
			JLabel g5=new JLabel("PDF "+decode_pdf.getPDFVersion()); 
			g5.setOpaque(false);
			g5.setFont(textFont);
			details.add(g5);
			
			details.add(Box.createVerticalStrut(10));
			
			//general details
			JLabel header2=new JLabel(Messages.getMessage("PdfViewerProperties"));
			header2.setFont(headFont);
			header2.setOpaque(false);
			details.add(header2);
			
			//get the document properties
			String[] values=currentFileInformation.getFieldValues();
			String[] fields=currentFileInformation.getFieldNames();
			
			//add to list and display
			int count=fields.length;
			
			JLabel[] displayValues=new JLabel[count];
			
			for(int i=0;i<count;i++){
				if(values[i].length()>0){
					
					displayValues[i]=new JLabel(fields[i]+" = "+values[i]);
					displayValues[i].setFont(textFont);
					displayValues[i].setOpaque(false);
					details.add(displayValues[i]);
				}
			}
			
			details.add(Box.createVerticalStrut(10));
			
			/**
			 * get the Pdf file information object to extract info from
			 */
			PdfPageData currentPageSize=decode_pdf.getPdfPageData();
			
			if(currentPageSize!=null){
			
				//general details
				JLabel header3=new JLabel(Messages.getMessage("PdfViewerCoords.text"));
				header3.setFont(headFont);
				details.add(header3);
				
				JLabel g6=new JLabel(Messages.getMessage("PdfViewermediaBox.text")+currentPageSize.getMediaValue(currentPage)); 
				g6.setFont(textFont);
				details.add(g6);
				
				JLabel g7=new JLabel(Messages.getMessage("PdfViewercropBox.text")+currentPageSize.getCropValue(currentPage)); 
				g7.setFont(textFont);
				details.add(g7);
				
				JLabel g8=new JLabel(Messages.getMessage("PdfViewerrotation.text")+currentPageSize.getRotation(currentPage)); 
				g3.setFont(textFont);
				details.add(g8);
				
			}
			
			details.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
			
			return scrollPane;
			
		}else{
			return new JScrollPane();
		}
	}
	
	
	/**
	 * page info option
	 */
	private JScrollPane getXMLInfoBox(String xmlText) {
			
		JPanel details=new JPanel();
		//<start-13>
		details.setLayout(new BoxLayout(details, BoxLayout.PAGE_AXIS));
		//<end-13>
		
		details.setOpaque(true);
		details.setBackground(Color.white);
		
		JScrollPane scrollPane=new JScrollPane();
		scrollPane.setPreferredSize(new Dimension(400,300));
		scrollPane.getViewport().add(details);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		JTextArea xml=new JTextArea();
		
		xml.setRows(5);
		xml.setColumns(15);
		xml.setLineWrap(true);
		xml.setText(xmlText);
		details.add(new JScrollPane(xml));
		xml.setCaretPosition(0);
		xml.setOpaque(true);
		xml.setBackground(Color.white);
		
		return scrollPane;
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#showDocumentProperties(java.lang.String, java.lang.String, long, int, int)
	 */
	public void showDocumentProperties(String selectedFile, String inputDir, long size, int pageCount,int currentPage) {
		JTabbedPane tabbedPane = new JTabbedPane();
		
		if(selectedFile == null){
			showMessageDialog(Messages.getMessage("PdfVieweremptyFile.message"),Messages.getMessage("PdfViewerTooltip.pageSize"),JOptionPane.PLAIN_MESSAGE);
		}else{
			tabbedPane.add(getPropertiesBox(selectedFile,inputDir,size,pageCount,currentPage));
			tabbedPane.setTitleAt(0, "Propertes");
			
			tabbedPane.add(getFontInfoBox());
			tabbedPane.setTitleAt(1, "Fonts");
			
			/**
			 * optional tab for new XML style info
			 */
			PdfFileInformation currentFileInformation=decode_pdf.getFileInformationData();
			String xmlText=currentFileInformation.getFileXMLMetaData();
			if(xmlText.length()>0){
				tabbedPane.add(getXMLInfoBox(xmlText));
				tabbedPane.setTitleAt(2, "XML");
			}
			
			showMessageDialog(tabbedPane, "Document Properties", JOptionPane.PLAIN_MESSAGE);
		}
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#init(java.lang.String[], org.jpedal.examples.simpleviewer.Commands, org.jpedal.examples.simpleviewer.utils.Printer)
	 */
	public void init(String[] scalingValues,final Commands currentCommands,Printer currentPrinter) {
		
		/**
		 * single listener to execute all commands
		 */
		currentCommandListener=new CommandListener(currentCommands);	
		
		/**
		 * set a title
		 */
		setViewerTitle(Messages.getMessage("PdfViewerOs.message")+"  " + PdfDecoder.version);
			/**/
		
		/**arrange insets*/
		decode_pdf.setInset(inset,inset);
		
		/**
		 * setup combo boxes
		 */
		qualityBox=new SwingCombo(qualityValues);
		qualityBox.setBackground(Color.white);
		qualityBox.setSelectedIndex(0); //set default before we add a listener	
		
		scalingBox=new SwingCombo(scalingValues);
		scalingBox.setBackground(Color.white);
		scalingBox.setEditable(true);
		scalingBox.setSelectedIndex(defaultSelection); //set default before we add a listener
		
		//if you enable, remember to change rotation and quality Comboboxes
		//scalingBox.setPreferredSize(new Dimension(85,25));
		
		rotationBox=rotationBox=new SwingCombo(rotationValues);
		rotationBox.setBackground(Color.white);
		rotationBox.setSelectedIndex(0); //set default before we add a listener
		
		/**
		 * add the pdf display to show page
		 **/
		scrollPane.getViewport().add(decode_pdf);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.getVerticalScrollBar().setUnitIncrement(80);
		scrollPane.getHorizontalScrollBar().setUnitIncrement(80);
		
		bottomNavButtons.setBorder(BorderFactory.createEmptyBorder());
		bottomNavButtons.setLayout(new FlowLayout(FlowLayout.LEADING));
		bottomNavButtons.setFloatable(false);
		bottomNavButtons.setFont(new Font("SansSerif", Font.PLAIN, 8)); 
		
		/**
		 * Create a left-right split pane with tabs 
		 * and add to main display 
		 */
		navOptionsPanel.setTabPlacement(JTabbedPane.TOP);
		displayPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, navOptionsPanel, scrollPane);
		displayPane.setOneTouchExpandable(true);
		frame.getContentPane().add(displayPane, BorderLayout.CENTER);
		
		/**Create a left-right split pane with tabs 
		 * and add to main display 
		 */
		navOptionsPanel.setTabPlacement(JTabbedPane.TOP);
		displayPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, navOptionsPanel, scrollPane);
		
		displayPane.setOneTouchExpandable(true);
		frame.getContentPane().add(displayPane, BorderLayout.CENTER);
		
		if(!thumbnails.isShownOnscreen())
			navOptionsPanel.setVisible(false);
		
		/**
		 * setup global buttons
		 */
		if(!commonValues.isContentExtractor()){
			first=new SwingButton();
			fback=new SwingButton();
			back=new SwingButton();
			forward=new SwingButton();
			fforward=new SwingButton();
			end=new SwingButton();
		}
		
		bookmarksButton=new SwingButton();
		snapshotButton=new SwingButton();
		
		
		/**
		 * set colours on display boxes and add listener to page number
		 */	
		pageCounter2.setEditable(true);
		pageCounter2.setToolTipText(Messages.getMessage("PdfViewerTooltip.goto")); 
		pageCounter2.setBorder(BorderFactory.createLineBorder(Color.black));
		
		pageCounter2.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent arg0) {
				
				String value=pageCounter2.getText().trim();
				
				currentCommands.gotoPage(value);
			}
			
		});
		pageCounter3=new JLabel(Messages.getMessage("PdfViewerOfLabel.text")+" "); 
		pageCounter3.setOpaque(false);
		
		/**
		 * create a menu bar and add to display
		 */
		JPanel top = new JPanel();
		top.setLayout(new BorderLayout());
		frame.getContentPane().add(top, BorderLayout.NORTH);
		
		/** nav bar at bottom to select pages and setup Toolbar on it*/
		JPanel bottom = new JPanel();
		bottom.setLayout(new BorderLayout());
		frame.getContentPane().add(bottom, BorderLayout.SOUTH);
		
		comboBar.setBorder(BorderFactory.createEmptyBorder());
		comboBar.setLayout(new FlowLayout(FlowLayout.CENTER));
		comboBar.setFloatable(false);
		comboBar.setFont(new Font("SansSerif", Font.PLAIN, 8));
		bottom.add(comboBar, BorderLayout.NORTH);
		
		/**
		 *setup menu and create options
		 */
		top.add(currentMenu, BorderLayout.NORTH);
		
		/**
		 * create other tool bars and add to display
		 */
		topButtons.setBorder(BorderFactory.createEmptyBorder());
		topButtons.setLayout(new FlowLayout(FlowLayout.LEADING));
		topButtons.setFloatable(false);
		topButtons.setFont(new Font("SansSerif", Font.PLAIN, 8)); 
		top.add(topButtons, BorderLayout.CENTER);
		
		/**
		 * zoom,scale,rotation, status,cursor
		 */
		top.add(bottomNavButtons , BorderLayout.SOUTH);
		
		
		/**
		 * navigation toolbar for moving between pages
		 */
		createNavbar();
		
		/**move over if we will display thumbnails*/
		if (thumbnails.isShownOnscreen())
			displayPane.setDividerLocation(thumbLocation);
		
		/**
		 * set display to occupy half screen size and display, add listener and
		 * make sure appears in centre
		 */
		if(commonValues.getModeOfOperation()!=Values.RUNNING_APPLET){
			Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
			int width = d.width / 2, height = d.height / 2;
			if(width<minimumScreenWidth)
				width=minimumScreenWidth;
			
			//if(width>650)
			//	width=650;
			frame.setSize(width, height);
			
			//<start-13>
			//centre on screen
			frame.setLocationRelativeTo(null);
			/*<end-13>
			frame.setLocation((d.width-frame.getWidth())/2,(d.height-frame.getHeight())/2);
			/**/
			
			frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			
			frame.addWindowListener(new FrameCloser(currentCommands, this,decode_pdf,currentPrinter,thumbnails,commonValues));
			
			frame.show();
		}
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#addCursor()
	 */
	public void addCursor(){
		
		/**add cursor location*/
		JToolBar cursor = new JToolBar();
		cursor.setBorder(BorderFactory.createEmptyBorder());
		cursor.setLayout(new FlowLayout(FlowLayout.LEADING));
		cursor.setFloatable(false);
		cursor.setFont(new Font("SansSerif", Font.ITALIC, 10)); //$NON-NLS-1$
		cursor.add(new JLabel(Messages.getMessage("PdfViewerCursorLoc"))); 
		
		cursor.add(initCoordBox());
		
		/**setup cursor*/
		topButtons.add(cursor);
		
	}
	
	/**setup keyboard shortcuts*/
	private void setKeyAccelerators(int ID,JMenuItem menuItem){
		
		switch(ID){
		
		case Commands.SAVE:
			menuItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S,
					java.awt.Event.CTRL_MASK));
			break;
		case Commands.PRINT:
			menuItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P,
					java.awt.Event.CTRL_MASK));
			break;
		case Commands.EXIT:
			menuItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q,
					java.awt.Event.CTRL_MASK));
			break;
		case Commands.DOCINFO:
			menuItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D,
					java.awt.Event.CTRL_MASK));
			break;
		case Commands.OPENFILE:
			menuItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O,
					java.awt.Event.CTRL_MASK));
			break;
		case Commands.OPENURL:
			menuItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U,
					java.awt.Event.CTRL_MASK));
			break;
		case Commands.PREVIOUSDOCUMENT:
			menuItem.setAccelerator( KeyStroke.getKeyStroke("alt shift LEFT"));
			break;
		case Commands.NEXTDOCUMENT:
			menuItem.setAccelerator( KeyStroke.getKeyStroke("alt shift RIGHT"));
			break;
		case Commands.FIRSTPAGE:
			menuItem.setAccelerator( KeyStroke.getKeyStroke("HOME"));
			break;
		case Commands.BACKPAGE:
			//menuItem.setAccelerator( KeyStroke.getKeyStroke("LEFT") );
			menuItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_LEFT,
					java.awt.Event.CTRL_MASK));
			break;
		case Commands.FORWARDPAGE:
			menuItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_RIGHT,
					java.awt.Event.CTRL_MASK));
			break;
		case Commands.LASTPAGE:
			menuItem.setAccelerator( KeyStroke.getKeyStroke("END"));
			break;
		case Commands.GOTO:
			menuItem.setAccelerator( KeyStroke.getKeyStroke("shift ctrl N") );
			break;
			
		}
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#addButton(int, java.lang.String, java.lang.String, int)
	 */
	public void addButton(int line,String toolTip,String path,final int ID) {
		
		GUIButton newButton = new SwingButton();
		
		/**specific buttons*/
		switch(ID){
		
		case Commands.FIRSTPAGE:
			newButton=first;
			break;
		case Commands.FBACKPAGE:
			newButton=fback;
			break;
		case Commands.BACKPAGE:
			newButton=back;
			break;
		case Commands.FORWARDPAGE:
			newButton=forward;
			break;
		case Commands.FFORWARDPAGE:
			newButton=fforward;
			break;
		case Commands.LASTPAGE:
			newButton=end;
			break;
		case Commands.BOOKMARK:
			newButton=bookmarksButton;
			break;
		case Commands.SNAPSHOT:
			newButton=snapshotButton;
		}
		
		if(ID==Commands.BOOKMARK){
			
			if(thumbnails.isShownOnscreen())
				toolTip=Messages.getMessage("PdfViewerShowide.bookmarks"); 
			else
				toolTip=Messages.getMessage("PdfViewerShowHide2.bookmarks");
		}
		
		newButton.init(path, ID,toolTip);
		
		//add listener
		((AbstractButton) newButton).addActionListener(currentCommandListener);
		
		//add to toolbar
		if(line==BUTTONBAR){
			topButtons.add((AbstractButton) newButton);
			topButtons.add(Box.createHorizontalGlue());
		}else if(line==NAVBAR){
			comboBar.add((AbstractButton) newButton);
			comboBar.add(Box.createHorizontalGlue());
		}
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#addMenuItem(javax.swing.JMenu, java.lang.String, java.lang.String, int)
	 */
	public void addMenuItem(JMenu parentMenu,String text,String toolTip,final int ID) {
		
		SwingMenuItem menuItem = new SwingMenuItem(text);
		menuItem.setToolTipText(toolTip);
		menuItem.setID(ID);
		setKeyAccelerators(ID,menuItem);
		
		//add listener
		menuItem.addActionListener(currentCommandListener);
		parentMenu.add(menuItem);
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#addCombo(java.lang.String, java.lang.String, int)
	 */
	public void addCombo(String title,String tooltip,int ID){
		
		GUICombo combo=null;
		switch (ID){
		case Commands.QUALITY:
			combo=qualityBox;
			break;
		case Commands.SCALING:
			combo=scalingBox;
			break;
		case Commands.ROTATION:
			combo=rotationBox;
			break;
			
		}
		
		combo.setID(ID);
		
		optimizationLabel = new JLabel(title); 
		combo.setToolTipText(tooltip); 
		
		bottomNavButtons.add(optimizationLabel);
		bottomNavButtons.add((SwingCombo) combo);
		
		//add listener
		((SwingCombo)combo).addActionListener(currentCommandListener);
		
	}
	
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#setViewerTitle(java.lang.String)
	 */
	public void setViewerTitle(final String title) {
		
		if(title!=null){
			frame.setTitle(title);
		}else{
			
			String finalMessage="";
			
			finalMessage=Messages.getMessage("PdfViewerOs.message")+"  " + PdfDecoder.version+" "+commonValues.getSelectedFile();
			  if(commonValues.isFormsChanged())
				finalMessage="* "+finalMessage;
			
			 frame.setTitle(finalMessage);
			   /**/
		}	
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#resetComboBoxes(boolean)
	 */
	public void resetComboBoxes(boolean value) {
		qualityBox.setEnabled(value);
		scalingBox.setEnabled(value);
		rotationBox.setEnabled(value);
		
	}
	
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#createPane(javax.swing.JTextPane, java.lang.String, boolean)
	 */
	public final JScrollPane createPane(JTextPane text_pane,String content, boolean useXML) throws BadLocationException {
		
		text_pane.setEditable(true);
		text_pane.setFont(new Font("Lucida", Font.PLAIN, 14)); 
		
		text_pane.setToolTipText(Messages.getMessage("PdfViewerTooltip.text")); 
		Document doc = text_pane.getDocument();
		text_pane.setBorder(BorderFactory.createTitledBorder(new EtchedBorder(), Messages.getMessage("PdfViewerTitle.text"))); 
		text_pane.setForeground(Color.black);
		
		SimpleAttributeSet token_attribute = new SimpleAttributeSet();
		SimpleAttributeSet text_attribute = new SimpleAttributeSet();
		SimpleAttributeSet plain_attribute = new SimpleAttributeSet();
		StyleConstants.setForeground(token_attribute, Color.blue);
		StyleConstants.setForeground(text_attribute, Color.black);
		StyleConstants.setForeground(plain_attribute, Color.black);
		int pointer=0;
		
		/**put content in and color XML*/
		if((useXML)&&(content!=null)){
			//tokenise and write out data
			StringTokenizer data_As_tokens = new StringTokenizer(content,"<>", true); 
			
			while (data_As_tokens.hasMoreTokens()) {
				String next_item = data_As_tokens.nextToken();
				
				if ((next_item.equals("<"))&&((data_As_tokens.hasMoreTokens()))) {
					
					String current_token = next_item + data_As_tokens.nextToken()+ data_As_tokens.nextToken();
					
					doc.insertString(pointer, current_token,token_attribute);
					pointer = pointer + current_token.length();
					
				} else {
					doc.insertString(pointer, next_item, text_attribute);
					pointer = pointer + next_item.length();
				}
			}
		}else
			doc.insertString(pointer,content, plain_attribute);
		
		//wrap in scrollpane
		JScrollPane text_scroll = new JScrollPane();
		text_scroll.getViewport().add( text_pane );
		text_scroll.setHorizontalScrollBarPolicy( JScrollPane.HORIZONTAL_SCROLLBAR_NEVER );
		text_scroll.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED );
		return text_scroll;
	}
	
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#getSelectedComboIndex(int)
	 */
	public int getSelectedComboIndex(int ID) {
		
		switch (ID){
		case Commands.QUALITY:
			return qualityBox.getSelectedIndex();
		case Commands.SCALING:
			return scalingBox.getSelectedIndex();
		case Commands.ROTATION:
			return rotationBox.getSelectedIndex();
		default:
			return -1;
		}
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#setSelectedComboIndex(int, int)
	 */
	public void setSelectedComboIndex(int ID,int index) {
		switch (ID){
		case Commands.QUALITY:
			qualityBox.setSelectedIndex(index);
			break;
		case Commands.SCALING:
			scalingBox.setSelectedIndex(index);
			break;
		case Commands.ROTATION:
			rotationBox.setSelectedIndex(index);
			break;
			
		}
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#setSelectedComboItem(int, java.lang.String)
	 */
	public void setSelectedComboItem(int ID,String index) {
		switch (ID){
		case Commands.QUALITY:
			qualityBox.setSelectedItem(index);
			break;
		case Commands.SCALING:
			scalingBox.setSelectedItem(index);
			break;
		case Commands.ROTATION:
			rotationBox.setSelectedItem(index);
			break;
			
		}
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#getSelectedComboItem(int)
	 */
	public Object getSelectedComboItem(int ID) {
		
		switch (ID){
		case Commands.QUALITY:
			return qualityBox.getSelectedItem();
		case Commands.SCALING:
			return scalingBox.getSelectedItem();
		case Commands.ROTATION:
			return rotationBox.getSelectedItem();
		default:
			return null;
		
		}
	}
	
	/**refresh screen display*/
	private void repaintScreen() {
		scrollPane.repaint();
		frame.validate();
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#zoom()
	 */
	public void zoom() {
		
		if(decode_pdf!=null){
			
			/** update value and GUI */
			int index=getSelectedComboIndex(Commands.SCALING);
			if(index==-1){
				String numberValue=(String)getSelectedComboItem(Commands.SCALING);
				
				float zoom=-1;
				if((numberValue!=null)&&(numberValue.length()>0)){
					try{
						zoom= Float.parseFloat(numberValue);
					}catch(Exception e){
						zoom=-1;
						//its got characters in it so get first valid number string
						int length=numberValue.length();
						int ii=0;
						while(ii<length){
							char c=numberValue.charAt(ii);
							if(((c>='0')&&(c<='9'))|(c=='.'))
								ii++;
							else
								break;
						}
						
						if(ii>0)
							numberValue=numberValue.substring(0,ii);
						
						//try again if we reset above
						if(zoom==-1){
							try{
								zoom= Float.parseFloat(numberValue);
							}catch(Exception e1){zoom=-1;}
						}
					}
					if(zoom>1000){
						zoom=1000;
					}
				}
				
				//if nothing off either attempt, use window value
				if(zoom==-1){
					//its not set so use To window value
					index=defaultSelection;
					setSelectedComboIndex(Commands.SCALING, index);
				}else{
					scaling=zoom/100;
					setSelectedComboItem(Commands.SCALING, zoom+"");	
				}
			}
			
			if(index!=-1){
				if(index<3){ //handle scroll to width/height/window
					
					PdfPageData pageData = decode_pdf.getPdfPageData();
					int cw,ch,raw_rotation=pageData.getRotation(commonValues.getCurrentPage());
					if(rotation==90 || rotation==270){
						cw = pageData.getCropBoxHeight(commonValues.getCurrentPage());
						ch = pageData.getCropBoxWidth(commonValues.getCurrentPage());
					}else{
						cw = pageData.getCropBoxWidth(commonValues.getCurrentPage());
						ch = pageData.getCropBoxHeight(commonValues.getCurrentPage());
					}
					
					//define pdf view width and height
					// MAY not need dividersize
					float width = scrollPane.getViewport().getWidth()-inset-inset-displayPane.getDividerSize();
					float height = scrollPane.getViewport().getHeight()-inset-inset;
					
					float x_factor=0,y_factor=0;
					x_factor = width / cw;
					y_factor = height / ch;
					
					if(index==0){//window
						if(x_factor<y_factor)
							scaling = x_factor;
						else
							scaling = y_factor;
					}else if(index==1)//height
						scaling = y_factor;
					else if(index==2)//width
						scaling = x_factor;
				}else{
					scaling=scalingFloatValues[index];
				}
			}
			
			//check for 0 to avoid error  and replace with 1
			PdfPageData pagedata = decode_pdf.getPdfPageData();
			if((pagedata.getCropBoxHeight(commonValues.getCurrentPage())*scaling<100) &&//keep the page bigger than 100 pixels high
					(pagedata.getCropBoxWidth(commonValues.getCurrentPage())*scaling<100) && commonValues.isPDF()){//keep the page bigger than 100 pixels wide
				scaling=1;
				setSelectedComboItem(Commands.SCALING,"100");
			}
			
			
			// THIS section commented out so altering scalingbox does NOT reset rotation
			//if(!scalingBox.getSelectedIndex()<3){
			/**update our components*/
			//resetRotationBox();
			//}
			
			if(decode_pdf!=null) //allow for clicking on it before page opened
				decode_pdf.setPageParameters(scaling, commonValues.getCurrentPage(),rotation);
			
			decode_pdf.invalidate();
			//decode_pdf.repaint();
			repaintScreen();
			
		}
		
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#rotate()
	 */
	public void rotate() {
		rotation=Integer.parseInt((String) getSelectedComboItem(Commands.ROTATION));
		
		zoom();
		
		decode_pdf.updateUI();
		
	}
	
	
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#decodePage(boolean)
	 */
	public void decodePage(final boolean resizePanel){
		
		boolean isContentExtractor=commonValues.isContentExtractor();
		
		/**ensure text and color extracted. If you do not need color, take out 
		 * line for faster decode
		 */
		
		//remove any search highlight
		decode_pdf.setFoundTextAreas(null);
		
		//remove highlighted text
		decode_pdf.setHighlightedAreas(null); 
		
		setRectangle(null);
		
		//stop user changing scaling while decode in progress
		resetComboBoxes(false);
		
		decode_pdf.clearScreen();
		
		/** if running terminate first */
		thumbnails.terminateDrawing();
		
		commonValues.setProcessing(true);
		
		/**
		 * add outline if appropriate in a scrollbar on the left to
		 * replicate L & F or Acrobat
		 */
		if (!hasOutlinesDrawn) {
			hasOutlinesDrawn=true;
			createOutlinePanels();
		}
		
		SwingWorker worker = new SwingWorker() {
			public Object construct() {
				
				
				try {
					
					statusBar.updateStatus("Decoding Page",0);
					
					/**
					 * make sure screen fits display nicely
					 */
					if ((resizePanel) && (thumbnails.isShownOnscreen())) 
						zoom();
					
					if (Thread.interrupted())
						throw new InterruptedException();
					
					/**
					 * decode the page
					 */
					try {
						decode_pdf.decodePage(commonValues.getCurrentPage());
						if(!decode_pdf.hasAllImages()){
							String status = "One or more images is not displayed\n"+
							"Most common cause is Insufficient memory to decode page\n"+
							"and display all images on this page\n\n"+
							"1) Try running java again, this time allocating it more memory.\n"+
							"This can be done using the -Xmx VM argument.\n"+
							"For example to allocate at least 256MB you would use java -Xmx256M ...\n\n"+
							"2) Set the Image Optimisation setting to Memory\n\n"
							+"Please contact IDRsolutions if you require any further advice";
							
							showMessageDialog(status); 
						}
						//read values for page display
						PdfPageData page_data = decode_pdf.getPdfPageData();
						
						mediaW  = page_data.getMediaBoxWidth(commonValues.getCurrentPage());
						mediaH = page_data.getMediaBoxHeight(commonValues.getCurrentPage());
						mediaX = page_data.getMediaBoxX(commonValues.getCurrentPage());
						mediaY = page_data.getMediaBoxY(commonValues.getCurrentPage());
						
						cropX = page_data.getCropBoxX(commonValues.getCurrentPage());
						cropY = page_data.getCropBoxY(commonValues.getCurrentPage());
						cropW = page_data.getCropBoxWidth(commonValues.getCurrentPage());
						cropH = page_data.getCropBoxHeight(commonValues.getCurrentPage());
						
						resetRotationBox();
						
						//<start-forms>
						//read annotations data
						commonValues.setPageAnnotations(decode_pdf.getPdfAnnotsData(null));
						//<end-forms>
						
						statusBar.updateStatus("Displaying Page",0); 
						
					} catch (Exception e) {
						System.err.println("Exception " + e + " decoding page");
						e.printStackTrace();
						commonValues.setProcessing(false);
					}
					
					pageCounter2.setForeground(Color.black);
					pageCounter2.setText(" " + commonValues.getCurrentPage()); 
					pageCounter3.setText(Messages.getMessage("PdfViewerOfLabel.text") +" "+ commonValues.getPageCount());
					
					//tell user if we had a memory error on decodePage
					String status=decode_pdf.getPageDecodeReport();
					if(status.indexOf("java.lang.OutOfMemoryErro")!=-1){
						status = "Insufficient memory to decode page and display all images on this page\n\n"+
						"1) Try running java again, this time allocating it more memory.\n"+
						"This can be done using the -Xmx VM argument.\n"+
						"For example to allocate at least 256MB you would use java -Xmx256M ...\n\n"+
						"2) Set the Image Optimisation setting to Memory\n\n"
						+"Please contact IDRsolutions if you require any further advice";
						
						showMessageDialog(status); 
						
					}
					//tell user about embedded fonts in Open Source version 
					if((decode_pdf.hasEmbeddedFonts())&&(!decode_pdf.supportsEmbeddedFonts())){
						showMessageDialog("Page contains embedded fonts which may not display correctly using Font substitution."); 
						
					}
					/**/
					if ((thumbnails.isShownOnscreen())) {
						thumbnails.addNewThumbnails(commonValues.getCurrentPage(),decode_pdf);
					} else
						commonValues.setProcessing(false);
					
					//make sure fully drawn
					//decode_pdf.repaint();
					
					//<start-13>
					setViewerTitle(null); //restore title
					//<end-13>
					
					
					if (thumbnails.isShownOnscreen()) {
						
						/**setup thumbnails in foreground*/
						thumbnails.setupThumbnailsOnDecode(commonValues.getCurrentPage(),decode_pdf);
						
					}
					
				} catch (Exception e) {
					//<start-13>
					setViewerTitle(null); //restore title
					//<end-13>
				}
				
				selectBookmark();
				
				
				statusBar.setProgress(100);
				
				//reanable user changing scaling 
				resetComboBoxes(true);
				
				
				//<start-forms>
				addFormsListeners();

                String message=null;
                if(decode_pdf.hasJavascript() && decode_pdf.isXFAForm()){
                    message="This PDF contains Javascript and XFA form objects\n" +
							"Support for XFA will be in JPedal release 3.0\n" +
					"Available from http://www.jpedal.org in 2006";

                }else if(decode_pdf.isXFAForm()){
                    message="This PDF contains XFA form objects\n" +
							"Support for these will be in JPedal release 3.0\n" +
					"Available from http://www.jpedal.org in 2006";
                }else if(decode_pdf.isXFAForm()){
                    message="This PDF contains Javascript objects\n" +
							"This is not currently supported";
                }

                if(message!=null)
                showMessageDialog(message);


                //<end-forms>
				
				return null;
			}
		};
		
		worker.start();
		
	}
	
	//<start-forms>
	/**this method adds listeners to GUI widgets to track changes*/
	private void addFormsListeners(){
		
		//rest forms changed flag to show no changes
		commonValues.setFormsChanged(false);
		
		/**see if flag set - not default behaviour*/
		boolean showMessage=false;
		String formsFlag=System.getProperty("listenForms");
		if(formsFlag!=null)
			showMessage=true;
		
		//get the form renderer which also contains the processed form data.
		//if you want simple form data, also look at the ExtractFormData.java example
		org.jpedal.objects.acroforms.AcroRenderer formRenderer=decode_pdf.getCurrentFormRenderer();
		
		if(formRenderer==null)
			return;
		
		//get list of forms on page
		java.util.List formsOnPage=null;
		
		/**
		 * Or you can also use 
		 * formRenderer.getDisplayComponentsForPage(commonValues.getCurrentPage());
		 * to get all components directly - we have already checked formRenderer not null
		 */     
		try {
			formsOnPage = formRenderer.getComponentNameList(commonValues.getCurrentPage());
		} catch (PdfException e) {
			
			LogWriter.writeLog("Exception "+e+" reading component list");
		}
		
		//allow for no forms
		if(formsOnPage==null){
			
			if(showMessage)
				showMessageDialog("No fields on this page");
			
			return;
		}
		
		int formCount=formsOnPage.size();
		
		JPanel formPanel=new JPanel();
		/**
		 * create a JPanel to list forms and tell user abox example
		 **/
		if(showMessage){
			formPanel.setLayout(new BoxLayout(formPanel,BoxLayout.Y_AXIS));
			JLabel formHeader = new JLabel("This page contains "+formCount+" form objects");
			formHeader.setFont(headFont);
			formPanel.add(formHeader);
			
			formPanel.add(Box.createRigidArea(new Dimension(10,10)));
			JTextPane instructions = new JTextPane();
			instructions.setPreferredSize(new Dimension(450,180));
			instructions.setEditable(false);
			instructions.setText("This provides a simple example of Forms handling. We have"+
					" added a listener to each form so clicking on it shows the form name.\n\n"+
					"Code is in addExampleListeners() in org.examples.simpleviewer.SimpleViewer\n\n"+
					"This could be easily be extended to interface with a database directly "+
					"or collect results on an action and write back using itext.\n\n"+
					"Forms have been converted into Swing components and are directly accessible"+
					" (as is the original data).\n\n"+
			"If you don't like the standard SwingSet you can replace with your own set.");
			instructions.setFont(textFont);
			formPanel.add(instructions);
			formPanel.add(Box.createRigidArea(new Dimension(10,10)));
		}
		
		/**
		 * access all forms in turn and add a listener
		 */
		for(int i=0;i<formCount;i++){
			
			//get name of form
			String formName=(String) formsOnPage.get(i);
			
			//get actual component - do not display it separately -
			//at the moment this will not work on group objects (ie radio buttons and checkboxes)
			Component[] comp=formRenderer.getComponentsByName(formName);
			
			/**
			 * add listeners on first decode - not needed if we revisit page
			 * 
			 * DO NOT remove listeners from Components as used internally to control appearance
			 */
			Integer pageKey=new Integer(i);
			if(comp!=null && pagesDecoded.get(pageKey)==null){
				
				//simple device to prevent multiple listeners
				pagesDecoded.put(pageKey,"x");
				
				//loop through all components returned
				int count=comp.length;
				for(int index=0;index<count;index++){
					
					//add details to screen display, group objects have the same name so add them only once 
					if((showMessage)&&(index==0)){
						JLabel type = new JLabel();
						JLabel label = new JLabel("Form name="+formName);
						String labelS = "type="+comp[index].getClass();
						if(count>1){
							labelS = "Group of "+count+" Objects, type="+comp[index].getClass();
							type.setForeground(Color.red);
						}
						type.setText(labelS);
						label.setFont(headFont);
						type.setFont(textFont);
						formPanel.add(label);
						formPanel.add(type);
						
						formPanel.add(new JLabel(" "));
					}
					
					//add listeners to show proof of concept - this
					//could equally be inserting into database
					
					//combo boxes
					FormActionListener changeList=new FormActionListener(formName+index,frame,showMessage);
					if(comp[index] instanceof JComboBox){ 
						((JComboBox)comp[index]).addActionListener(changeList);
					}else if(comp[index] instanceof JCheckBox){ 
						((JCheckBox)comp[index]).addActionListener(changeList);
					}else if(comp[index] instanceof JRadioButton){ 
						((JRadioButton)comp[index]).addActionListener(changeList);
					}else if(comp[index] instanceof JTextField){ 
						((JTextField)comp[index]).addActionListener(changeList);
					}
				}
			}
		}
		
		/**
		 * pop-up to show forms on page
		 **/	
		if(showMessage){
			final JDialog displayFrame =  new JDialog(frame,true);
			if(commonValues.getModeOfOperation()!=Values.RUNNING_APPLET){
				displayFrame.setLocationRelativeTo(null);
				displayFrame.setLocation(frame.getLocationOnScreen().x+10,frame.getLocationOnScreen().y+10);
			}
			
			JScrollPane scroll=new JScrollPane();
			scroll.getViewport().add(formPanel);
			scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			
			displayFrame.setSize(500,500);
			displayFrame.setTitle("List of forms on this page");
			displayFrame.getContentPane().setLayout(new BorderLayout());
			displayFrame.getContentPane().add(scroll,BorderLayout.CENTER);
			
			JPanel buttonBar=new JPanel();
			buttonBar.setLayout(new BorderLayout());
			displayFrame.getContentPane().add(buttonBar,BorderLayout.SOUTH);
			
			// close option just removes display
			JButton no=new JButton("Close");
			no.setFont(new Font("SansSerif", Font.PLAIN, 12)); 
			buttonBar.add(no,BorderLayout.EAST);
			no.addActionListener(new ActionListener(){
				
				public void actionPerformed(ActionEvent e) {
					displayFrame.dispose();
				}});
			
			/**show the popup*/
			displayFrame.show();
		}
		
	}
	//<end-forms>
	
	/**
	 *  put the outline data into a display panel which we can pop up 
	 * for the user - outlines, thumbnails
	 */
	private void createOutlinePanels() {
		
		boolean hasNavBars=false;
		
		/**
		 * set up first 10 thumbnails by default. Rest created as needed.
		 */
		//add if statement or comment out this section to remove thumbnails
		if(thumbnails.isShownOnscreen()){
			
			int pages=decode_pdf.getPageCount();
			
			if(pages>100){
				thumbnails.setIsDisplayedOnscreen(false);
				LogWriter.writeLog("Thumbnails not used on files over 100 pages long");
			}else{
				hasNavBars=true;
				//setup and add to display
				
				//##Token:PdfViewerTitle.thumbnails=Thumbnails
				navOptionsPanel.add(thumbnails.setupThumbnails(pages,textFont,Messages.getMessage("PdfViewerPageLabel.text"),decode_pdf.getPdfPageData())
						,Messages.getMessage("PdfViewerTitle.thumbnails"));
				
				//add listener so clicking on button changes to page - has to be in SimpleViewer so it can update it
				Object[] buttons=thumbnails.getButtons();
				for(int i=0;i<pages;i++)
					((JButton)buttons[i]).addActionListener(new PageChanger(i));
				
				//<start-13>
				//add global listener
				thumbnails.addComponentListener();
				//<end-13>
				
			}
			
		}
		
		/**
		 * add any outline
		 */
		if(decode_pdf.hasOutline()&& showOutlines){
			
			hasNavBars=true;
			/**graphical display*/
			
			Node rootNode= decode_pdf.getOutlineAsXML().getFirstChild();
			if(rootNode!=null){
				
				tree=new SwingOutline(rootNode);
				
				//##Token:PdfViewerTitle.bookmarks=Bookmarks
				navOptionsPanel.add((Component) tree,Messages.getMessage("PdfViewerTitle.bookmarks"));
				
				//Listen for when the selection changes - looks up dests at present
				((JTree) tree.getTree()).addTreeSelectionListener(new TreeSelectionListener(){
					
					/** Required by TreeSelectionListener interface. */
					public void valueChanged(TreeSelectionEvent e) {
						
						if(tree.isIgnoreAlteredBookmark())
							return;
						
						DefaultMutableTreeNode node = tree.getLastSelectedPathComponent();
						
						if (node == null) return;
						
						Object nodeInfo = node.getUserObject();
						
						/**get title and open page if valid*/
						String title=(String)node.getUserObject();
						String page=tree.getPage(title);
						
						if((page!=null)&&(page.length()>0)){
							int pageToDisplay=Integer.parseInt(page);
							
							if((!commonValues.isProcessing())&&(commonValues.getCurrentPage()!=pageToDisplay)){
								commonValues.setCurrentPage(pageToDisplay);
								/**reset as rotation may change!*/
								setScalingToDefault();
								
								decode_pdf.setPageParameters(getScaling(), commonValues.getCurrentPage());
								decodePage(false);
							}
							
							Point p= tree.getPoint(title);
							if(p!=null)
								decode_pdf.ensurePointIsVisible(p);
							
						}else
							System.out.println("No dest page set for "+title);
					}
				});
				
			}else{
				//there is a nav bar but no values so do not display
				hasNavBars=false;
				bookmarksButton.setEnabled(false);
			}
		}
		
		/**
		 * resize to show if there are nav bars
		 */
		if(hasNavBars){
			if(!thumbnails.isShownOnscreen()){
				if( !commonValues.isContentExtractor())
				navOptionsPanel.setVisible(true);   
				displayPane.setDividerLocation(divLocation);
				displayPane.invalidate();
				displayPane.repaint();
				
			}
		}
	}
	
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#removeOutlinePanels()
	 */
	public void removeOutlinePanels() {
		
		/**
		 * reset left hand nav bar
		 */
		thumbnails.removeAll();
		if(tree!=null)
			tree.setMinimumSize(new Dimension(50,frame.getHeight()));
		if(!thumbnails.isShownOnscreen())
			navOptionsPanel.setVisible(false);
		navOptionsPanel.removeAll();
		
		/**flag for redraw*/
		hasOutlinesDrawn=false;
		
		/**update GUI button*/
		bookmarksButton.setEnabled(decode_pdf.hasOutline());
	}
	
	
	private void selectBookmark() {
		if(decode_pdf.hasOutline()&&(tree!=null)) 
			tree.selectBookmark();
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#togglePDFOutline()
	 */
	public void togglePDFOutline() {
		
		boolean current=!navOptionsPanel.isVisible();
		navOptionsPanel.setVisible(current);
		if(current)
			displayPane.setDividerLocation(divLocation);
		else
			displayPane.setDividerLocation(0);
		
	}
	
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#initStatus()
	 */
	public void initStatus() {
		decode_pdf.setStatusBarObject(statusBar);
		resetStatus();
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#resetStatus()
	 */
	public void resetStatus() {
		//set status bar child color
		statusBar.setColorForSubroutines(Color.blue);
		//and initialise the display
		bottomNavButtons.add(statusBar.getStatusObject());
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#initThumbnails(int, org.jpedal.utils.repositories.Vector_Int)
	 */
	public void initThumbnails(int itemSelectedCount, Vector_Int pageUsed) {
		navOptionsPanel.removeAll();
		
		displayPane.setDividerLocation(divLocation);
		
		navOptionsPanel.add(thumbnails.setupThumbnails(itemSelectedCount-1,pageUsed.get(),commonValues.getPageCount()),"Extracted items");
		
		
	}
	
//	<start-forms>
	class FormActionListener implements ActionListener{
		
		private Container c;
		private String formName;
		boolean showMessage;
		
		public FormActionListener(String formName, Container c,boolean showMessage) {
			
			this.c=c;
			this.formName=formName;
			this.showMessage=showMessage;
			
		}
		
		public void actionPerformed(ActionEvent arg0) {
			
			Object comp =arg0.getSource();
			Object value=null;
			if(comp instanceof JComboBox)
				value=((JComboBox)comp).getSelectedItem();
			else if(comp instanceof JCheckBox)
				value=""+((JCheckBox)comp).isSelected();
			else if(comp instanceof JRadioButton)
				value=""+((JRadioButton)comp).isSelected();
			else if(comp instanceof JTextField)
				value=""+((JTextField)comp).getText();
			
			{
				boolean showSaveFormsMessage = properties.getValue("showsaveformsmessage").equals("true");
				
				if(showSaveFormsMessage && firstTimeFormMessage && commonValues.isFormsChanged()==false){
					firstTimeFormMessage=false;
					
					JPanel panel =new JPanel();
					panel.setLayout(new GridBagLayout());
					final GridBagConstraints p = new GridBagConstraints();
					
					p.anchor=GridBagConstraints.WEST;
					p.gridx = 0;
					p.gridy = 0;
					
					String str="You have changed a form value.\nYou can save a copy of the form from menu File-ReSave Forms As";
					if(!commonValues.isItextOnClasspath())
						str="You have changed a form value.\nIf you had itext on the classpath,\nJPedal would allow you to resave the form";
					
					JCheckBox cb=new JCheckBox();
					cb.setText("Don't show this again");
					Font font = cb.getFont();
					
					JTextArea ta=new JTextArea(str);
					ta.setOpaque(false);
					ta.setFont(font);
					
					p.ipady=20;
					panel.add(ta, p);
					
					p.ipady=0;
					p.gridy = 1;
					panel.add(cb,p);
					
					JOptionPane.showMessageDialog(c,panel);
					
					if(cb.isSelected())
						properties.setValue("showsaveformsmessage","false");
					
				}
			}
			commonValues.setFormsChanged(true);
			setViewerTitle(null);
			
			if(showMessage)
				JOptionPane.showMessageDialog(c,"FormName >>"+formName+"<<. Value changed to "+value);
			
		}
	}
	//<end-forms>
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#setCoordText(java.lang.String)
	 */
	public void setCoordText(String string) {
		coords.setText(string);
	}
	
	private JLabel initCoordBox() {
		
		coords.setBackground(Color.white);
		coords.setOpaque(true);
		coords.setBorder(BorderFactory.createLineBorder(Color.black,1));
		
		return coords;
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#toggleSnapshotButton()
	 */
	public void toggleSnapshotButton() {
			snapshotButton.setIcon(new ImageIcon(getClass().getResource("/org/jpedal/examples/simpleviewer/res/snapshot.gif")));
		
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#setPageNumber()
	 */
	public void setPageNumber() {
		pageCounter2.setForeground(Color.black);
		pageCounter2.setText(" " + commonValues.getCurrentPage());
		pageCounter3.setText(Messages.getMessage("PdfViewerOfLabel.text") +" "+ commonValues.getPageCount()); //$NON-NLS-1$
	}
	
	private void createNavbar() {
		
		JLabel pageCounter1 = new JLabel(Messages.getMessage("PdfViewerPageLabel.text")); 
		pageCounter1.setOpaque(false);
		
		/**
		 * navigation toolbar for moving between pages
		 */
		addButton(NAVBAR,Messages.getMessage("PdfViewerRewindToStart"),"/org/jpedal/examples/simpleviewer/res/start.gif",Commands.FIRSTPAGE);
		
		addButton(NAVBAR,Messages.getMessage("PdfViewerRewind10"),"/org/jpedal/examples/simpleviewer/res/fback.gif",Commands.FBACKPAGE);
		
		addButton(NAVBAR,Messages.getMessage("PdfViewerRewind1"),"/org/jpedal/examples/simpleviewer/res/back.gif",Commands.BACKPAGE);
		
		/**put page count in middle of forward and back*/
		comboBar.add(pageCounter1);
		comboBar.add(pageCounter2);
		comboBar.add(pageCounter3);
		
		addButton(NAVBAR,Messages.getMessage("PdfViewerForward1"),"/org/jpedal/examples/simpleviewer/res/forward.gif",Commands.FORWARDPAGE);
		
		addButton(NAVBAR,Messages.getMessage("PdfViewerForward10"),"/org/jpedal/examples/simpleviewer/res/fforward.gif",Commands.FFORWARDPAGE);
		
		addButton(NAVBAR,Messages.getMessage("PdfViewerForwardLast"),"/org/jpedal/examples/simpleviewer/res/end.gif",Commands.LASTPAGE);
		
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#addToMainMenu(javax.swing.JMenu)
	 */
	public void addToMainMenu(JMenu fileMenuList) {
		currentMenu.add(fileMenuList);
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#getFrame()
	 */
	public JFrame getFrame() {
		return frame;
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#getTopButtonBar()
	 */
	public JToolBar getTopButtonBar() {
		return topButtons;
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#showMessageDialog(java.lang.Object)
	 */
	public void showMessageDialog(Object message1){
		JOptionPane.showMessageDialog(frame,message1);
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#showMessageDialog(java.lang.Object, java.lang.String, int)
	 */
	public void showMessageDialog(Object message,String title,int type){
		JOptionPane.showMessageDialog(frame,message,title,type);
	}
	
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#showInputDialog(java.lang.Object, java.lang.String, int)
	 */
	public String showInputDialog(Object message, String title, int type) {
		return JOptionPane.showInputDialog(frame, message, title, type);
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#showInputDialog(java.lang.String)
	 */
	public String showInputDialog(String message) {
		
		return 	JOptionPane.showInputDialog(frame,message);
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#showOptionDialog(java.lang.Object, java.lang.String, int, int, java.lang.Object, java.lang.Object[], java.lang.Object)
	 */
	public int showOptionDialog(Object displayValue, String message, int option, int type, Object icon, Object[] options, Object initial) {
		
		return JOptionPane.showOptionDialog(frame, displayValue,message,option,type, (Icon)icon, options,initial);
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#showConfirmDialog(java.lang.String, java.lang.String, int)
	 */
	public int showConfirmDialog(String message, String message2, int option) {
		
		return JOptionPane.showConfirmDialog(frame, message,message2,option);
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#showOverwriteDialog(String file,boolean yesToAllPresent)
	 */
	public int showOverwriteDialog(String file,boolean yesToAllPresent) {
		
		int n = -1;
		
		if(yesToAllPresent){
			
			final Object[] buttonRowObjects = new Object[] { 
					"Yes", "Yes To All", "No", "Cancel"
			};
			
			n = JOptionPane.showOptionDialog(frame, 
					file+"\nThe file already exists\nReplace the existing file?",
					"Overwrite?",
					JOptionPane.DEFAULT_OPTION,
					JOptionPane.QUESTION_MESSAGE,
					null,
					buttonRowObjects,
					buttonRowObjects[0]);
			
		}else{
			n = JOptionPane.showOptionDialog(frame, 
					file+"\nThe file already exists\nReplace the existing file?",
					"Overwrite?",
					JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE,
					null,null,null);
		}
		
		return n;
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#showMessageDialog(javax.swing.JTextArea)
	 */
	public void showMessageDialog(JTextArea info) {
		JOptionPane.showMessageDialog(frame, info);
		
	}
	
	public void showItextPopup() {
		JEditorPane p = new JEditorPane(
				"text/html",
				"Itext is not on the classpath.<BR>"
						+ "JPedal includes code to take advantage of itext and<BR>"
						+ "provide additional functionality with options<BR>"
						+ "to spilt pdf files, and resave forms data<BR>"
						+ "\nItext website - <a href=http://www.lowagie.com/iText/>http://www.lowagie.com/iText/</a>");
		p.setEditable(false);
		p.setOpaque(false);
		p.addHyperlinkListener( new HyperlinkListener() {
			public void hyperlinkUpdate(HyperlinkEvent e) {
				if (e.getEventType().equals(HyperlinkEvent.EventType.ACTIVATED)) {
					try {
						BrowserLauncher.openURL("http://www.lowagie.com/iText/");
					} catch (IOException e1) {
						showMessageDialog("Unable to launch browser");
					}
				}
			}
		});
		
		//<start-13>
		showMessageDialog(p);
		//<end-13>
		
		// Hack for 13 to make sure the message box is large enough to hold the message
		//<start-13>
		/**
		//<end-13>
		JOptionPane optionPane = new JOptionPane();
		optionPane.setMessage(p);
		optionPane.setMessageType(JOptionPane.INFORMATION_MESSAGE);
		optionPane.setOptionType(JOptionPane.DEFAULT_OPTION);
		
		JDialog dialog = optionPane.createDialog(frame, "iText");
		dialog.pack();
		dialog.setSize(400,200);
		dialog.show(); 
		/**/
		
	}
	
	public void showFirstTimePopup(){
		
		try{
			final JPanel a = new JPanel();
			a.setLayout(new BorderLayout());
			JLabel lab=new JLabel(new ImageIcon(getClass().getResource("/org/jpedal/objects/acroforms/ceo.jpg")));
			
			//lab.setBorder(BorderFactory.createRaisedBevelBorder());
			a.add(lab,BorderLayout.NORTH);
			final JLabel message=new JLabel("<html>JPedal library from www.jpedal.org");
			message.setHorizontalAlignment(JLabel.CENTER);
			message.setForeground(Color.blue);
			message.setFont(new Font("Lucida",Font.PLAIN,16));
			
			message.addMouseListener(new MouseListener() {
				public void mouseEntered(MouseEvent e) {
					a.setCursor(new Cursor(Cursor.HAND_CURSOR));
					message.setText("<html><a href=http://www.jpedal.org>JPedal library from www.jpedal.org</a>");
				}
				
				public void mouseExited(MouseEvent e) {
					a.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
					message.setText("<html>JPedal library from www.jpedal.org");
				}
				
				public void mouseClicked(MouseEvent e) {
					try {
						BrowserLauncher.openURL("http://www.jpedal.org");
					} catch (IOException e1) {
						showMessageDialog("Unable to launch browser");
					}
				}
				
				public void mousePressed(MouseEvent e) {}
				public void mouseReleased(MouseEvent e) {}
			});	
			
			
			a.add(message,BorderLayout.CENTER);
			
			a.setPreferredSize(new Dimension(300,214));
			Object[] options = { "Run Software" };
			int n =
				JOptionPane.showOptionDialog(
						frame,
						a,
						"Running JPedal for first Time",
						JOptionPane.DEFAULT_OPTION,
						JOptionPane.PLAIN_MESSAGE,
						null,
						options,
						options[0]);
		}catch(Exception e){
			//JOptionPane.showMessageDialog(null, "caught an exception "+e);
			System.err.println("Unable to find image and setup splash screen");
		}catch(Error e){
			//JOptionPane.showMessageDialog(null, "caught an error "+e);
			System.err.println("Unable to find image and setup splash screen");
		}
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#showConfirmDialog(java.lang.Object, java.lang.String, int, int)
	 */
	public void showConfirmDialog(Object label, String message, int option, int plain_message) {
		JOptionPane.showConfirmDialog(frame,label,message,option,plain_message);
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#initPDFOutlines(org.w3c.dom.Node, java.lang.String)
	 */
	public String initPDFOutlines(Node rootNode, String bookmark) {
		
		tree=new SwingOutline(rootNode);
		
		tree.readChildNodes(rootNode,null);
		
		return tree.getPage(bookmark);
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#removeThumbnails()
	 */
	public void removeThumbnails() {
		displayPane.setDividerLocation(0);
		setPDFOutlineVisible(false);
		navOptionsPanel.removeAll();
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#setSplitDividerLocation(int)
	 */
	public void setSplitDividerLocation(int size) {
		displayPane.setDividerLocation(size);
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#updateStatusMessage(java.lang.String)
	 */
	public void updateStatusMessage(String message) {
		statusBar.updateStatus(message,0);
		
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#resetStatusMessage(java.lang.String)
	 */
	public void resetStatusMessage(String message) {
		statusBar.resetStatus(message);
		
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#setStatusProgress(int)
	 */
	public void setStatusProgress(int size) {
		statusBar.setProgress(size);	
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#isPDFOutlineVisible()
	 */
	public boolean isPDFOutlineVisible() {
		return navOptionsPanel.isVisible();
	}
	
	/* (non-Javadoc)
	 * @see org.jpedal.examples.simpleviewer.gui.swing.GUIFactory#setPDFOutlineVisible(boolean)
	 */
	public void setPDFOutlineVisible(boolean visible) {
		navOptionsPanel.setVisible(visible);
	}


    public void setQualityBoxVisible(boolean visible){
		qualityBox.setVisible(visible);
		optimizationLabel.setVisible(visible);
	}
}
