If you wish to recompile the source code, you should use the
supplied build.xml file under Ant. 

This copies all resources and certain required class files 
into the new jar as well as compiling the source code.

This build expects the file 14_os_jpedal.jar and the src directory 
to be at the same level as this build.xml file.

If you wish to recompile the whole library, you will need pjes.jar on the classpath.

Compiling the examples does not require pjes.jar

