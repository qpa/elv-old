package com.javadocking.util;

/**
 * This class determines the version of the Java Virtual Machine.
 * 
 * @author Heidi Rakels.
 */
public class JvmVersionUtil
{
	
	// Static fields.

	/** System property <code>java.vm.version</code> starts with this string for java version 1.1. */
	private static final String VERSION_STRING_1 = "1.1";
	/** System property <code>java.vm.version</code> starts with this string for java version 1.2. */
	private static final String VERSION_STRING_2 = "1.2";
	/** System property <code>java.vm.version</code> starts with this string for java version 1.3. */
	private static final String VERSION_STRING_3 = "1.3";
	/** System property <code>java.vm.version</code> starts with this string for java version 1.4. */
	private static final String VERSION_STRING_4 = "1.4";
	/** System property <code>java.vm.version</code> starts with this string for java version 5. */
	private static final String VERSION_STRING_5 = "1.5";
	/** System property <code>java.vm.version</code> starts with this string for java version 6. */
	private static final String VERSION_STRING_6 = "1.6";
	
	/** The integer for java 1.1 versions of the JVM. */
	public static final int VERSION_1 = 1;
	/** The integer for java 1.2 versions of the JVM. */
	public static final int VERSION_2 = 2;
	/** The integer for java 1.3 versions of the JVM. */
	public static final int VERSION_3 = 3;
	/** The integer for java 1.4 versions of the JVM. */
	public static final int VERSION_4 = 4;
	/** The integer for java 5 versions of the JVM. */
	public static final int VERSION_5 = 5;
	/** The integer for java 6 versions of the JVM. */
	public static final int VERSION_6 = 6;
	
	// Public static methods.
	
	/**
	 * Gets the version of the JVM. 
	 * 
	 * @return		The integer that corresponds with the version of the JVM. This can be 
	 * 				VERSION_1, VERSION_2, VERSION_3, VERSION_4, VERSION_5 or VERSION_6.
	 * @throws 		IllegalStateException 	If the system property <code>java.vm.version</code> does not start with
	 * 										VERSION_STRING_1, VERSION_STRING_2, VERSION_STRING_3, VERSION_STRING_4, 
	 * 										VERSION_STRING_5 or VERSION_STRING_6.
	 */
	public static int getVersion() 
	{
		
		// Get the system property java.vm.version.
		String jvmVersion = System.getProperty("java.vm.version");
		
		// Determine the version from this string.
		if (jvmVersion.startsWith(VERSION_STRING_6))
		{
			return VERSION_6;
		}
		if (jvmVersion.startsWith(VERSION_STRING_5))
		{
			return VERSION_5;
		}
		if (jvmVersion.startsWith(VERSION_STRING_4))
		{
			return VERSION_4;
		}
		if (jvmVersion.startsWith(VERSION_STRING_3))
		{
			return VERSION_3;
		}
		if (jvmVersion.startsWith(VERSION_STRING_2))
		{
			return VERSION_2;
		}
		if (jvmVersion.startsWith(VERSION_STRING_1))
		{
			return VERSION_1;
		}
		
		throw new IllegalStateException("This java version ["+ jvmVersion + "] is not supported.");
		
	}
	
	// Test.
	
//	public static void main(String[] args) {
//		
//		String version = System.getProperty("java.vm.version");
//		System.out.println("Version number: " + getVersion());
//		System.out.println("Version string: " + version);
//		
//	}
	
	// Private constructor.
	
	private JvmVersionUtil()
	{
	}
}
