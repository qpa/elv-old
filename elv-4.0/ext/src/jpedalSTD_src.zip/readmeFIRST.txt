The src directory contains the source code for all the org.jpedal classes
for JPedal and the build.xml to recreate under Ant.

Please read readMeBeforeCompiling for details on how to setup and compile the code.

If you wish to use JPedal (or any part) in a GPL product, you merely need to ensure you
fully comply with the GPL license.

Otherwise you must obtain a commercial license to use it.

The font code is part of the Java Font Library which is available under a joint dual/GPL license

IDRsolutions
August 2006
