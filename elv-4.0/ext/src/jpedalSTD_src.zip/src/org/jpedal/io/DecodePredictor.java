package org.jpedal.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public class DecodePredictor extends InputStream{

  private boolean eof_ = false;

  private int pred_;
  private int colors_, bitsper_;
  
  private byte[] lastline_, line_;   // not byte[] as bitsper_ can be 16
  private int linei_;
  private int col0_;    // left for first byte
  private int rowlen_;
  
  InputStream uncached=null;
  InputStream cached=null;

  int ptr=0;
  
  //final boolean debug=true;
  

  /**uses Tom Phelps code modified to add a Predictor wrapper. There is also a very good 
   * description in Compressed Image file formats (Addison Wesley) Miano 
   */

  /**
	If prediction is 1 (TIFF no prediction) or 10 (PNG no prediction), there is no use in applying a DecodePredictor filter.
  */
  public DecodePredictor(byte[] data, int pred, Map params, BufferedInputStream bis)  {

	//if(debug)
    if(data!=null)
    	uncached=new ByteArrayInputStream(data);
    if(bis!=null)
        cached=bis;

    pred_ = pred;

	colors_=1;
	String value = (String) params.get("Colors");
	if (value != null)
		colors_ = Integer.parseInt(value);

	bitsper_=8;
	value = (String) params.get("BitsPerComponent");
	if (value != null)
		bitsper_ = Integer.parseInt(value);

	int cols=1;
	value = (String) params.get("Columns");
	if (value != null)
		cols= Integer.parseInt(value);

	//if (bitsper_>8) PDF.sampledata("Predictor "+pred+" bitsper="+bitsper_);
	col0_ = (colors_ * bitsper_ + 7) / 8;   // same as bpp

	rowlen_ = (cols * colors_ * bitsper_ + 7) / 8 + col0_/*0 for left predictions*/;  // exclusive of predictor
	line_=new byte[rowlen_]; lastline_=new byte[line_.length];

	nextRow();


  }

  private void nextRow()  {
	// reset output
	byte[] tmp=lastline_; lastline_=line_; line_=tmp;   // line_ becomes lastline_ without copying
	byte[] l=line_, ll=lastline_;
	linei_ = col0_;

	// per line predictor?
	int pred = pred_;
	if (pred==15) {
		
//		if(ptr==data.length)
//			pred=-1;
//		else{
//			pred=data[ptr];
//			ptr++;
//		}
		
		//if(debug){
        try{
        	int oldPred1=0,oldPred2=0;
        	if(uncached!=null){
				oldPred1=uncached.read();
				pred=oldPred1;
        	}
        	if(cached!=null){
        		oldPred2 = cached.read();  // take from line_ -- so have to be before read line
        		pred=oldPred2;
        	}
        	if((cached!=null)&&(uncached!=null)){
        		if(oldPred2!=oldPred1){
        			System.out.println("1Different predictors byte="+oldPred1+" stream="+oldPred2);
        			System.exit(1);
        		}
        	}
        	
        }catch(Exception e){
            e.printStackTrace();
        }
//			if(oldPred!=pred){
//				System.out.println("Predictor is "+pred+" should be "+oldPred);
//				System.exit(1);
//			}
		//}
		
		if (pred==-1) { eof_=true; return; }
		pred += 10;     // embedded numbered like this

	} else if (pred>=10){ 
		
		//ptr++;
		//if(debug)
        try {
        	int oldPred1=0,oldPred2=0;
        	if(uncached!=null){
				oldPred1=uncached.read();
				//pred=oldPred1;
        	}
        	if(cached!=null){
        		oldPred2 = cached.read();  // take from line_ -- so have to be before read line
        		//pred=oldPred2;
        	}
        	if((cached!=null)&&(uncached!=null)){
        		if(oldPred2!=oldPred1){
        			System.out.println("2Different predictors byte="+oldPred1+" stream="+oldPred2);
        			System.exit(1);
        		}
        	}
            //in.read();	// WRONG! BUT! Acrobat seems to do it, as for isaacs-15.pdf w/Predictor 12 on PDF 1.5 Xref
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	// read data
	int len = col0_;
	for (int maxlen=rowlen_; len < maxlen; ) {

		int hunk = 0;
//		int hunk=maxlen-len;
//		int initialPtr = ptr;
//		for(int i=len;i<maxlen;i++){
//			l[i] = data[ptr];
//			ptr++;
//		}
//		
//		ptr = hunk + initialPtr;

		//if(debug){
			byte[] oldl=new byte[l.length];
			
			//int oldHunk = in.read(oldl, len, maxlen-len);

        try {
        	int hunk1=0,hunk2=0;
        	if(uncached!=null){
				hunk1= uncached.read(l, len, maxlen-len);
				hunk=hunk1;
        	}
        	if(cached!=null){
        		hunk2= cached.read(l, len, maxlen-len);
				hunk=hunk2;
        	}
        	if((cached!=null)&&(uncached!=null)){
        		if(hunk2!=hunk1){
        			System.out.println("1Different hunk values byte="+hunk1+" stream="+hunk2);
        			System.exit(1);
        		}
        	}
        	
        } catch (IOException e) {
            e.printStackTrace();
        }

//			if(hunk!=oldHunk){
//				System.out.println("Wrong hunk "+hunk+" "+oldHunk);
//				System.exit(1);
//			}
			
//			for(int ii=0;ii<l.length;ii++){
//				if(l[ii]!=oldl[ii]){
//					System.out.println("hunk error "+l[ii]+" "+oldl[ii]);
//					System.exit(1);
//				}
//			}
		//}
		
		if (hunk != -1)
			len += hunk;
		else {
			eof_ = true;
			return;
		}
	}

	// process prediction for row
	int bpp = (colors_ * bitsper_ + 7) / 8;
	switch (pred) {
	case 1: // No prediction (default)
		break;

	case 2: // TIFF Predictor 2
		for (int i=col0_; i<len; i++) l[i] += l[i-bpp];   // FIX: respect BitsPerPixel
		break;

	case 10:    // None
		break;
	case 11:    // Sub -- left
		for (int i=col0_; i<len; i++) l[i] += l[i-bpp];   // signed bytes OK
		break;
	case 12:    // Up -- above
		for (int i=col0_; i<len; i++) l[i] += ll[i];  // signed bytes OK
		break;
	case 13:    // Average -- (left + above) / 2
		for (int i=col0_; i<len; i++) l[i] += ((l[i-bpp]&0xff) + (ll[i]&0xff))/2;
		break;
	case 14:    // Paeth -- closest of left, above, upper-left
		for (int i=col0_; i<len; i++) {
			int a=l[i-bpp]&0xff, b=ll[i]&0xff, c=ll[i-bpp]&0xff;    // Java should have unsigned bytes
			int p = a + b - c;  // initial estimate
			int pa=p-a, pb=p-b, pc=p-c;   // distances to a, b, c

			if(pa<0)
				pa=-pa;
			if(pb<0)
				pb=-pb;
			if(pc<0)
				pc=-pc;
			int val = pa<=pb && pa<=pc? a: pb<=pc? b: c;

			l[i] += (byte)val;
		}
		break;
	case 15:    // optimum -- per line determination
		break;

	//default:
		//assert false: pred+" vs "+pred_;    // unknown algorithm
	}
  }


  public int read(byte[] b, int off, int len) throws IOException {
	
	if (eof_) return -1;

	else if (linei_==rowlen_) {
		nextRow();
		return read(b, off, len);

	} else {
		//len = Math.min(len, rowlen_-linei_);
		int len2=rowlen_-linei_;
		if(len<len2)
			len=len2;
		System.arraycopy(line_,linei_, b,off, len);
		linei_ += len;
	}

	return len;
  }

    public int available() throws IOException {
    	
    	int avail=0;
    	if(cached!=null){
    		avail=cached.available();
    }
    	if(uncached!=null){
    		avail=uncached.available();
    	}

    	if(cached!=null && uncached!=null){
    		if(cached.available()!=uncached.available()){
    			System.out.println("Different available figures uncached="+uncached.available()+" cached="+cached.available());
    			System.exit(1);
    		}
    	}
    	
        return avail;    
    }

    public int read() throws IOException {
      int b;

      if (eof_) b=-1;
      else if (linei_ < rowlen_) b = (line_[linei_++] & 0xff);
      else {
          nextRow();
          return read();
      }

      return b;
    }

public void close() {
	//if(debug){
		try {
			if(cached!=null)
			cached.close();
			if(uncached!=null)
				uncached.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	//}
}

}
