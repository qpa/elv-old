package org.jpedal.color;

import java.awt.PaintContext;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.TexturePaint;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.io.Serializable;

public class PdfTexturePaint extends TexturePaint implements PdfPaint {

	public PdfTexturePaint(BufferedImage txtr, Rectangle2D anchor) {
		super(txtr, anchor);
	}

	public void setScaling(double cropX,double cropH,float scaling){

	}

	public boolean isPattern() {
		return false;
	}

	public void setPattern(int dummy) {

	}

	public int getRGB() {
		return 0;
	}

}
